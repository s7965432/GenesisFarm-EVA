using System.Linq;
using Genesis.Core;
using UnityEngine;

namespace Genesis.AI
{
    public sealed class EVAAgent : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public Transform Player { get; set; }
        public float MoveSpeed = 3.3f;
        public float AvoidanceRadius = .34f;
        private float _thinkTimer;
        private Vector3 _moveTarget;
        private bool _hasMoveTarget;
        private readonly RaycastHit[] _avoidHits = new RaycastHit[8];

        private void Update()
        {
            if (Runtime == null) return;
            AdvanceMovement();
            Runtime.State.Eva.X = Mathf.RoundToInt(transform.position.x);
            Runtime.State.Eva.Y = Mathf.RoundToInt(transform.position.z);
            _thinkTimer -= Time.deltaTime;
            if (_thinkTimer > 0) return;
            _thinkTimer = .35f;
            Think();
        }

        private void Think()
        {
            var s = Runtime.State;
            var dry = s.Plots.Where(p => p.Planted && !p.Watered && !p.Ready)
                .OrderBy(p => Runtime.Distance(s.Eva.X, s.Eva.Y, p.X, p.Y)).FirstOrDefault();

            if (s.Eva.Sleepiness >= .92f || s.Eva.Energy <= 15f)
            {
                SetBehavior("Resting", "Sleep");
                MoveToward(new Vector3(3, 0, 3));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, 3, 3) <= 1)
                {
                    s.Eva.Energy = Mathf.Min(100f, s.Eva.Energy + 35f);
                    s.Eva.Sleepiness = Mathf.Max(0f, s.Eva.Sleepiness - .55f);
                    s.AddEvent("EVARested", "home");
                }
                return;
            }

            if (s.Chicken.Owned && s.Chicken.Hunger >= .6f)
            {
                SetBehavior("Planning", "FeedChicken");
                if (s.Inventory.Feed <= 0)
                {
                    SetBehavior("MovingToShop", "FeedChicken");
                    MoveToward(new Vector3(19.2f, 0, 5));
                    if (Runtime.Distance(s.Eva.X, s.Eva.Y, 21, 5) <= 2)
                    {
                        SetBehavior("BuyingFeed", "FeedChicken");
                        if (!Runtime.BuyFeed("eva")) SetBehavior("Blocked", "FeedChickenBlockedNoCoin");
                    }
                    return;
                }
                SetBehavior("MovingToCoop", "FeedChicken");
                MoveToward(new Vector3(15, 0, 5));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, 15, 5) <= 1)
                {
                    SetBehavior("Feeding", "FeedChicken");
                    Runtime.FeedChicken("eva");
                }
                return;
            }

            if (s.Eva.KnowsWater && dry != null)
            {
                SetBehavior("Planning", "WaterCrops");
                if (s.Inventory.WateringCanWater <= 0)
                {
                    SetBehavior("MovingToWell", "WaterCrops");
                    MoveToward(new Vector3(2, 0, 10));
                    if (Runtime.Distance(s.Eva.X, s.Eva.Y, 2, 10) <= 1)
                    {
                        s.Inventory.WateringCanWater = 20;
                        s.AddEvent("EVAFillWateringCan", "farm_well");
                    }
                    return;
                }
                SetBehavior("MovingToCrop", "WaterCrops");
                MoveToward(new Vector3(dry.X, 0, dry.Y));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, dry.X, dry.Y) <= 1)
                {
                    SetBehavior("Watering", "WaterCrops");
                    Runtime.Water(dry.X, dry.Y, "eva");
                }
                return;
            }

            SetBehavior("Following", "FollowPlayer");
            if (Player != null && Vector3.Distance(transform.position, Player.position) > 3f) MoveToward(Player.position);
            else StopMoving();
        }

        private void SetBehavior(string behavior, string goal)
        {
            Runtime.State.Eva.BehaviorState = behavior;
            Runtime.State.Eva.CurrentGoal = goal;
        }

        private void MoveToward(Vector3 target)
        {
            target.y = transform.position.y;
            _moveTarget = target;
            _hasMoveTarget = true;
        }

        private void StopMoving()
        {
            _hasMoveTarget = false;
        }

        private void AdvanceMovement()
        {
            if (!_hasMoveTarget) return;
            var desired = _moveTarget - transform.position;
            desired.y = 0f;
            if (desired.sqrMagnitude <= .04f)
            {
                StopMoving();
                return;
            }
            desired.Normalize();

            var step = MoveSpeed * Time.deltaTime;
            var origin = transform.position + Vector3.up * .55f;
            var steer = desired;
            if (!IsDirectionClear(origin, desired, Mathf.Max(step, .12f)))
            {
                var left = Quaternion.Euler(0f, -55f, 0f) * desired;
                var right = Quaternion.Euler(0f, 55f, 0f) * desired;
                steer = IsDirectionClear(origin, left, .35f) ? left : IsDirectionClear(origin, right, .35f) ? right : Vector3.zero;
            }

            if (steer.sqrMagnitude < .01f) return;
            transform.position += steer.normalized * step;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(steer.normalized), 1f - Mathf.Exp(-12f * Time.deltaTime));
        }

        private bool IsDirectionClear(Vector3 origin, Vector3 direction, float step)
        {
            var count = Physics.SphereCastNonAlloc(origin, AvoidanceRadius, direction.normalized, _avoidHits, step + .2f, ~0, QueryTriggerInteraction.Ignore);
            for (var i = 0; i < count; i++)
            {
                var hit = _avoidHits[i];
                if (hit.collider == null || hit.transform == transform || hit.transform.IsChildOf(transform)) continue;
                if (Player != null && (hit.transform == Player || hit.transform.IsChildOf(Player))) continue;
                return false;
            }
            return true;
        }
    }
}
