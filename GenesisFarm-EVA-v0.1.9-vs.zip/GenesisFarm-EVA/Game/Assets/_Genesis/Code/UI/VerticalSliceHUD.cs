using Genesis.Core;
using Genesis.Gameplay;
using Genesis.Interaction;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.UI
{
    public sealed class VerticalSliceHUD : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public PlayerInteractor Interactor { get; set; }
        public PlayerMotor Motor { get; set; }
        public GameSessionControls Session { get; set; }
        public InteractionActionFeedback Feedback { get; set; }
        public string Message = "WASD移動｜Shift衝刺｜右鍵鏡頭｜滾輪縮放｜E互動｜1~4工具｜F1說明｜Esc暫停｜F11全螢幕";
        public System.Action SaveRequested;
        public System.Action LoadRequested;
        public UnityVerticalSliceVerifier Verifier { get; set; }
        public UnityVerticalSliceScenarioRunner Scenario { get; set; }

        private GUIStyle _title;
        private GUIStyle _body;
        private GUIStyle _prompt;
        private GUIStyle _focus;
        private GUIStyle _centerTitle;
        private GUIStyle _small;

        private void Update()
        {
            var k = Keyboard.current;
            if (k == null || Runtime == null) return;
            if (k.f5Key.wasPressedThisFrame) SaveRequested?.Invoke();
            if (k.f9Key.wasPressedThisFrame) LoadRequested?.Invoke();
            if (k.tKey.wasPressedThisFrame) Message = Runtime.TalkAboutRecentMemory();
        }

        private void EnsureStyles()
        {
            if (_title != null) return;
            _title = new GUIStyle(GUI.skin.label) { fontSize = 16, fontStyle = FontStyle.Bold };
            _title.normal.textColor = Color.white;
            _body = new GUIStyle(GUI.skin.label) { fontSize = 13 };
            _body.normal.textColor = Color.white;
            _prompt = new GUIStyle(GUI.skin.label) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            _prompt.normal.textColor = Color.white;
            _focus = new GUIStyle(GUI.skin.label) { fontSize = 12, alignment = TextAnchor.MiddleCenter };
            _focus.normal.textColor = new Color(.92f, .92f, .92f);
            _centerTitle = new GUIStyle(_title) { fontSize = 28, alignment = TextAnchor.MiddleCenter };
            _small = new GUIStyle(_body) { fontSize = 11, alignment = TextAnchor.MiddleCenter };
        }

        private void OnGUI()
        {
            if (Runtime == null) return;
            EnsureStyles();
            var s = Runtime.State;

            DrawWorldStatus(s);
            DrawEvaCard(s);
            DrawToolBar(s);
            DrawCrosshair();
            DrawInteractionPrompt();
            DrawActionFeedback();

            if (Verifier != null && !string.IsNullOrEmpty(Verifier.LastReport))
                GUI.Label(new Rect(12, Screen.height - 150, 980, 22), Verifier.LastReport, _small);
            if (Scenario != null && !string.IsNullOrEmpty(Scenario.LastReport))
                GUI.Label(new Rect(12, Screen.height - 128, 1180, 22), Scenario.LastReport, _small);

            if (Session != null && Session.ShowHelp) DrawHelp();
            if (Session != null && Session.IsPaused) DrawPause();
        }

        private void DrawWorldStatus(WorldRuntimeState s)
        {
            GUI.Box(new Rect(12, 12, 455, 112), "");
            GUI.Label(new Rect(24, 20, 420, 24), "Genesis Farm: EVA  " + GameBootstrap.Version, _title);
            GUI.Label(new Rect(24, 49, 420, 20), $"Day {s.Day}  {s.Minute/60:00}:{s.Minute%60:00}  {s.Weather}  {(s.Player.X >= 18 ? "Town" : "Farm")}", _body);
            GUI.Label(new Rect(24, 72, 420, 20), $"Coin {s.Inventory.Coin}   Seed {s.Inventory.RadishSeed}   Radish {s.Inventory.Radish}   Feed {s.Inventory.Feed}", _body);
            GUI.Label(new Rect(24, 95, 420, 20), $"Water {s.Inventory.WateringCanWater}/20   Chicken {(s.Chicken.Owned ? $"Hunger {s.Chicken.Hunger:0.00} / Eggs {s.Chicken.Eggs}" : "not owned")}", _body);
        }

        private void DrawEvaCard(WorldRuntimeState s)
        {
            var width = 330f;
            var x = Screen.width - width - 12f;
            GUI.Box(new Rect(x, 12, width, 112), "");
            GUI.Label(new Rect(x + 14, 20, width - 28, 22), "EVA", _title);
            GUI.Label(new Rect(x + 14, 48, width - 28, 20), $"Goal  {s.Eva.CurrentGoal}", _body);
            GUI.Label(new Rect(x + 14, 70, width - 28, 20), $"State {s.Eva.BehaviorState}", _body);
            GUI.Label(new Rect(x + 14, 92, width - 28, 20), $"Water K {s.Eva.WaterKnowledge:0.00}  Farm XP {s.Eva.FarmingXp}  Animal XP {s.Eva.AnimalCareXp}", _small);
        }

        private void DrawToolBar(WorldRuntimeState s)
        {
            var width = 500f;
            var x = (Screen.width - width) * .5f;
            var y = Screen.height - 62f;
            GUI.Box(new Rect(x, y, width, 50f), "");
            var tools = new[] { "hoe", "seed", "water", "harvest" };
            var labels = new[] { "1 鋤頭", "2 種子", "3 水壺", "4 收成" };
            for (var i = 0; i < tools.Length; i++)
            {
                var selected = Interactor != null && Interactor.SelectedTool == tools[i];
                var text = selected ? "[ " + labels[i] + " ]" : labels[i];
                GUI.Label(new Rect(x + 10 + i * 120, y + 8, 115, 22), text, selected ? _prompt : _focus);
            }
            var state = Motor != null && Motor.IsSprinting ? "SPRINT" : Motor != null && Motor.IsMoving ? "WALK" : "IDLE";
            GUI.Label(new Rect(x + 10, y + 29, width - 20, 17), state + "   |   " + (string.IsNullOrEmpty(Interactor?.LastMessage) ? Message : Interactor.LastMessage), _small);
        }

        private void DrawCrosshair()
        {
            var x = Screen.width * .5f;
            var y = Screen.height * .5f;
            GUI.Label(new Rect(x - 10, y - 14, 20, 28), "+", _prompt);
        }

        private void DrawInteractionPrompt()
        {
            if (Interactor == null || string.IsNullOrEmpty(Interactor.FocusPrompt)) return;
            var width = 380f;
            var x = (Screen.width - width) * .5f;
            var y = Screen.height - 146f;
            GUI.Box(new Rect(x, y, width, 66f), "");
            GUI.Label(new Rect(x + 10, y + 7, width - 20, 20), Interactor.FocusName, _focus);
            GUI.Label(new Rect(x + 10, y + 28, width - 20, 28), Interactor.FocusPrompt, _prompt);
        }

        private void DrawActionFeedback()
        {
            if (Feedback == null || Feedback.Pulse <= 0f || string.IsNullOrEmpty(Feedback.Label)) return;
            var alpha = Mathf.Clamp01(Feedback.Pulse);
            var old = GUI.color;
            GUI.color = new Color(1f, 1f, 1f, alpha);
            GUI.Label(new Rect(Screen.width * .5f - 180f, Screen.height * .5f + 34f, 360f, 28f), Feedback.Label, _prompt);
            GUI.color = old;
        }

        private void DrawHelp()
        {
            var w = 610f;
            var h = 230f;
            var x = (Screen.width - w) * .5f;
            var y = (Screen.height - h) * .5f;
            GUI.Box(new Rect(x, y, w, h), "");
            GUI.Label(new Rect(x + 20, y + 16, w - 40, 34), "操作說明", _centerTitle);
            GUI.Label(new Rect(x + 30, y + 62, w - 60, 145),
                "WASD / 方向鍵：移動     Shift：衝刺\n右鍵拖曳：旋轉鏡頭     滾輪：縮放     E：互動\n1 鋤頭   2 白蘿蔔種子   3 水壺   4 收成\nT：讓 EVA 談最近真實記憶     F5：存檔     F9：讀檔\nF7：完整 Vertical Slice 驗收     F8：Runtime 狀態驗證\nF11：全螢幕     Esc：暫停     F1：關閉本說明", _body);
        }

        private void DrawPause()
        {
            GUI.Box(new Rect(0, 0, Screen.width, Screen.height), "");
            GUI.Label(new Rect(Screen.width * .5f - 220f, Screen.height * .5f - 55f, 440f, 50f), "PAUSED", _centerTitle);
            GUI.Label(new Rect(Screen.width * .5f - 220f, Screen.height * .5f + 2f, 440f, 28f), "按 Esc 繼續", _prompt);
        }
    }
}
