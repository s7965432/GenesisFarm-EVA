using Genesis.Core;
using UnityEngine;

namespace Genesis.UI
{
    public sealed class EVAWorldStatus : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public Vector3 WorldOffset = new(0f, 1.85f, 0f);

        private GUIStyle _nameStyle;
        private GUIStyle _stateStyle;

        private void EnsureStyles()
        {
            if (_nameStyle != null) return;
            _nameStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
                fontSize = 14
            };
            _nameStyle.normal.textColor = Color.white;
            _stateStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 11
            };
            _stateStyle.normal.textColor = new Color(.95f, .75f, .9f);
        }

        private void OnGUI()
        {
            if (Runtime == null || Camera.main == null) return;
            var screen = Camera.main.WorldToScreenPoint(transform.position + WorldOffset);
            if (screen.z <= 0f) return;
            EnsureStyles();
            var y = Screen.height - screen.y;
            GUI.Label(new Rect(screen.x - 90, y - 18, 180, 20), "EVA", _nameStyle);
            GUI.Label(new Rect(screen.x - 120, y, 240, 18), $"{Runtime.State.Eva.CurrentGoal} · {Runtime.State.Eva.BehaviorState}", _stateStyle);
        }
    }
}
