using UnityEngine;

namespace Genesis.UI
{
    public sealed class InteractionActionFeedback : MonoBehaviour
    {
        public float Pulse { get; private set; }
        public bool Success { get; private set; }
        public string Label { get; private set; } = "";

        public void Trigger(string label, bool success)
        {
            Label = label;
            Success = success;
            Pulse = 1f;
        }

        private void Update()
        {
            if (Pulse <= 0f) return;
            Pulse = Mathf.MoveTowards(Pulse, 0f, Time.unscaledDeltaTime * 3.4f);
        }
    }
}
