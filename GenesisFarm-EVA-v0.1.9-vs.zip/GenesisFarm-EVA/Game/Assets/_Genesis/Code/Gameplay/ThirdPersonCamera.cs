using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Gameplay
{
    public sealed class ThirdPersonCamera : MonoBehaviour
    {
        public Transform Target;
        public float Distance = 7.5f;
        public float MinDistance = 3.0f;
        public float MaxDistance = 11f;
        public float Height = 1.35f;
        public float Yaw = 25f;
        public float Pitch = 34f;
        public float MouseSensitivity = .16f;
        public float ZoomSensitivity = .015f;
        public float Follow = 14f;
        public float CollisionRadius = .22f;

        private void Start()
        {
            if (Target != null) SnapToTarget();
        }

        private readonly RaycastHit[] _collisionHits = new RaycastHit[12];

        private void LateUpdate()
        {
            if (Target == null) return;
            HandleInput();

            var pivot = Target.position + Vector3.up * Height;
            var rotation = Quaternion.Euler(Pitch, Yaw, 0f);
            var desiredDirection = rotation * Vector3.back;
            var desiredDistance = Distance;

            var hitCount = Physics.SphereCastNonAlloc(pivot, CollisionRadius, desiredDirection, _collisionHits, Distance, ~0, QueryTriggerInteraction.Ignore);
            var nearest = float.MaxValue;
            for (var i = 0; i < hitCount; i++)
            {
                var hit = _collisionHits[i];
                if (hit.collider == null || hit.transform == Target || hit.transform.IsChildOf(Target)) continue;
                if (hit.distance < nearest) nearest = hit.distance;
            }
            if (nearest < float.MaxValue) desiredDistance = Mathf.Max(MinDistance * .55f, nearest - .18f);

            var desired = pivot + desiredDirection * desiredDistance;
            transform.position = Vector3.Lerp(transform.position, desired, 1f - Mathf.Exp(-Follow * Time.deltaTime));
            transform.rotation = Quaternion.LookRotation(pivot - transform.position, Vector3.up);
        }

        private void HandleInput()
        {
            var mouse = Mouse.current;
            if (mouse == null) return;

            if (mouse.rightButton.isPressed)
            {
                var delta = mouse.delta.ReadValue();
                Yaw += delta.x * MouseSensitivity;
                Pitch -= delta.y * MouseSensitivity;
                Pitch = Mathf.Clamp(Pitch, 12f, 68f);
            }

            var scroll = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(scroll) > .01f)
                Distance = Mathf.Clamp(Distance - scroll * ZoomSensitivity, MinDistance, MaxDistance);
        }

        public void SnapToTarget()
        {
            var pivot = Target.position + Vector3.up * Height;
            var rotation = Quaternion.Euler(Pitch, Yaw, 0f);
            transform.position = pivot + rotation * Vector3.back * Distance;
            transform.rotation = Quaternion.LookRotation(pivot - transform.position, Vector3.up);
        }
    }
}
