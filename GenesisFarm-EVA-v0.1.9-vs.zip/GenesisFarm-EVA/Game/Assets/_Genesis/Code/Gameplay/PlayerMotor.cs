using Genesis.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Gameplay
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerMotor : MonoBehaviour
    {
        public float WalkSpeed = 4.2f;
        public float SprintSpeed = 6.8f;
        public float RotateSpeed = 14f;
        public float Gravity = -22f;
        public VerticalSliceRuntime Runtime { get; set; }

        public bool IsMoving { get; private set; }
        public bool IsSprinting { get; private set; }

        private CharacterController _controller;
        private float _verticalVelocity;
        private int _lastGridX;
        private int _lastGridY;

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();
            _lastGridX = Mathf.RoundToInt(transform.position.x);
            _lastGridY = Mathf.RoundToInt(transform.position.z);
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;

            var input = Vector2.zero;
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1;
            input = Vector2.ClampMagnitude(input, 1f);

            var cameraTransform = Camera.main != null ? Camera.main.transform : null;
            var forward = cameraTransform != null ? cameraTransform.forward : Vector3.forward;
            var right = cameraTransform != null ? cameraTransform.right : Vector3.right;
            forward.y = 0f;
            right.y = 0f;
            forward.Normalize();
            right.Normalize();

            var planar = forward * input.y + right * input.x;
            if (planar.sqrMagnitude > 1f) planar.Normalize();

            IsMoving = planar.sqrMagnitude > .01f;
            IsSprinting = IsMoving && (keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed);
            var speed = IsSprinting ? SprintSpeed : WalkSpeed;

            if (_controller.isGrounded && _verticalVelocity < 0f) _verticalVelocity = -2f;
            else _verticalVelocity += Gravity * Time.deltaTime;

            var motion = planar * speed;
            motion.y = _verticalVelocity;
            _controller.Move(motion * Time.deltaTime);

            if (IsMoving)
            {
                var targetRotation = Quaternion.LookRotation(planar, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, 1f - Mathf.Exp(-RotateSpeed * Time.deltaTime));
            }

            SyncRuntimeGrid();
        }

        private void SyncRuntimeGrid()
        {
            if (Runtime == null) return;
            var x = Mathf.Clamp(Mathf.RoundToInt(transform.position.x), 0, VerticalSliceRuntime.Width - 1);
            var y = Mathf.Clamp(Mathf.RoundToInt(transform.position.z), 0, VerticalSliceRuntime.Height - 1);
            if (x == _lastGridX && y == _lastGridY) return;
            Runtime.TravelPlayer(x, y);
            _lastGridX = x;
            _lastGridY = y;
        }
    }
}
