using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Gameplay
{
    public sealed class GameSessionControls : MonoBehaviour
    {
        public bool IsPaused { get; private set; }
        public bool ShowHelp { get; private set; }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;

            if (keyboard.escapeKey.wasPressedThisFrame)
                SetPaused(!IsPaused);

            if (keyboard.f1Key.wasPressedThisFrame)
                ShowHelp = !ShowHelp;

            if (keyboard.f11Key.wasPressedThisFrame)
                Screen.fullScreen = !Screen.fullScreen;
        }

        public void SetPaused(bool paused)
        {
            IsPaused = paused;
            Time.timeScale = paused ? 0f : 1f;
            Cursor.visible = paused;
        }

        private void OnDisable()
        {
            if (Time.timeScale == 0f) Time.timeScale = 1f;
        }
    }
}
