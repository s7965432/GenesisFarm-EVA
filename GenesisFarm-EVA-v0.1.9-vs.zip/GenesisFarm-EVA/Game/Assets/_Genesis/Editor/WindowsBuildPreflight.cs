#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Genesis.Editor
{
    public static class WindowsBuildPreflight
    {
        private const string ScenePath = "Assets/_Genesis/Scenes/VerticalSlice.unity";
        private const string ManifestPath = "Packages/manifest.json";
        private const string RuntimeRoot = "Assets/_Genesis/Code";

        public static void ValidateOrThrow()
        {
            var errors = new System.Collections.Generic.List<string>();
            if (!File.Exists(ScenePath)) errors.Add("VerticalSlice scene is missing");
            if (!File.Exists(ManifestPath)) errors.Add("Packages/manifest.json is missing");
            else
            {
                var manifest = File.ReadAllText(ManifestPath);
                if (!manifest.Contains("com.unity.inputsystem")) errors.Add("Input System package missing");
                if (!manifest.Contains("com.unity.render-pipelines.universal")) errors.Add("URP package missing");
            }

            string[] requiredScripts =
            {
                "Core/GameBootstrap.cs",
                "Core/VerticalSliceRuntime.cs",
                "Core/UnityVerticalSliceScenarioRunner.cs",
                "Gameplay/PlayerMotor.cs",
                "Gameplay/ThirdPersonCamera.cs",
                "Gameplay/GameSessionControls.cs",
                "Interaction/PlayerInteractor.cs",
                "UI/VerticalSliceHUD.cs",
                "World/VerticalSliceRuntimeBootstrap.cs"
            };
            foreach (var relative in requiredScripts)
                if (!File.Exists(Path.Combine(RuntimeRoot, relative))) errors.Add("Missing runtime script: " + relative);

            if (errors.Count > 0)
                throw new BuildFailedException("Windows preflight failed:\n- " + string.Join("\n- ", errors));

            Debug.Log("GENESIS_WINDOWS_PREFLIGHT_PASS 0.1.9-vs");
        }

        [MenuItem("Genesis/Run Windows Build Preflight")]
        public static void RunFromMenu()
        {
            if (!File.Exists(ScenePath)) VerticalSliceSceneBuilder.Build();
            ValidateOrThrow();
        }
    }
}
#endif
