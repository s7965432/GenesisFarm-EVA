# Genesis Farm: EVA — v0.1.9-vs

This package moves the verified Vertical Slice from engineering proof toward a PC-playable presentation layer while keeping the deterministic acceptance chain intact.

## v0.1.9 focus
- Added PC session controls: `Esc` pause/resume, `F1` help overlay, and `F11` fullscreen toggle.
- Rebuilt the HUD into separate world-status, EVA-status, quick-tool, contextual interaction, pause/help, and transient action-feedback layers.
- Interaction focus now originates from the actual camera-screen center ray while still enforcing player-to-target physical range.
- Successful/failed farm actions emit short on-screen feedback instead of only changing debug text.
- EVA decision cadence remains 0.35 seconds, but movement execution is now frame-smoothed using `Time.deltaTime`; obstacle probes try left/right steering before declaring the route blocked.
- Adjusted EVA town-shop approach so collision-aware movement can reach a valid purchase distance instead of trying to walk through the shop collider.
- Added `Genesis > Run Windows Build Preflight` and made Windows build run the same preflight automatically.
- Windows preflight checks the generated scene, required packages and critical runtime scripts before calling `BuildPipeline.BuildPlayer`; build metadata is stamped to 0.1.9.
- Unity F7 full Vertical Slice and browser deterministic oracle remain mandatory regression gates.

## Unity controls
- WASD / arrow keys: move relative to camera
- Shift: sprint
- Hold RMB + move mouse: orbit camera
- Mouse wheel: camera zoom
- 1 / 2 / 3 / 4: till / plant / water / harvest
- E: contextual interaction
- T: ask EVA about recent grounded memory
- F5 / F9: save / load player slot
- F1: toggle controls/help overlay
- Esc: pause / resume
- F11: toggle fullscreen
- F7: run the full Unity Vertical Slice Scenario
- F8: verify current Unity runtime state

## Build path
Unity Editor menu:
- `Genesis > Build Vertical Slice Scene`
- `Genesis > Run Windows Build Preflight`
- `Genesis > Build Windows x64`

Windows target remains `Build/Windows/GenesisFarm-EVA.exe`.

## Verification status
- Browser deterministic scenario: PASS 37/37.
- 35 named acceptance nodes preserved.
- Duplicate offline transaction guard: PASS.
- Unity engineering/static gate: PASS.
- Unity Editor compile, Windows x64 executable launch, and Android device run: UNVERIFIED in this environment.
