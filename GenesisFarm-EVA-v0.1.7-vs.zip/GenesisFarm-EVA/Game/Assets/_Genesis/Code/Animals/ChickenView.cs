using Genesis.Core;
using UnityEngine;

namespace Genesis.Animals
{
    public sealed class ChickenView : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        private Renderer _renderer;
        private Collider _collider;
        private void Awake() { _renderer = GetComponent<Renderer>(); _collider = GetComponent<Collider>(); }
        private void Update()
        {
            if (Runtime == null) return;
            var owned = Runtime.State.Chicken.Owned;
            if (_renderer != null)
            {
                _renderer.enabled = owned;
                if (owned) _renderer.material.color = Color.Lerp(Color.white, new Color(1f, .5f, .25f), Runtime.State.Chicken.Hunger);
            }
            if (_collider != null) _collider.enabled = owned;
        }
    }
}
