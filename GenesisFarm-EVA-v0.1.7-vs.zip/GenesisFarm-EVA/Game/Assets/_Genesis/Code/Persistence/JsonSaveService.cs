using System.IO;
using Genesis.Core;
using UnityEngine;

namespace Genesis.Persistence
{
    public sealed class JsonSaveService
    {
        public string PathName => Path.Combine(Application.persistentDataPath, "genesis-vs-slot-1.json");
        public void Save(WorldRuntimeState state) => Save(state, PathName);
        public void Save(WorldRuntimeState state, string path)
        {
            state.Version = GameBootstrap.Version;
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, JsonUtility.ToJson(state, true));
        }

        public WorldRuntimeState Load() => Load(PathName);
        public WorldRuntimeState Load(string path)
        {
            if (!File.Exists(path)) return null;
            var state = JsonUtility.FromJson<WorldRuntimeState>(File.ReadAllText(path));
            if (state == null) return null;
            state.Version = GameBootstrap.Version;
            state.Offline ??= new OfflineRuntimeState();
            state.Diary ??= new System.Collections.Generic.List<DiaryRuntimeState>();
            state.Eva.Memories ??= new System.Collections.Generic.List<MemoryRuntimeState>();
            if (string.IsNullOrEmpty(state.Eva.BehaviorState)) state.Eva.BehaviorState = "Restored";
            state.AddEvent("SaveLoaded", GameBootstrap.Version);
            state.AddEvent("WorldStateRestored", GameBootstrap.Version);
            return state;
        }
    }
}
