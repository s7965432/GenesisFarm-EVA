using UnityEngine;

namespace Genesis.Gameplay
{
    public sealed class ThirdPersonCamera : MonoBehaviour
    {
        public Transform Target;
        public Vector3 Offset = new(0f, 8f, -8f);
        public float Follow = 8f;

        private void LateUpdate()
        {
            if (Target == null) return;
            var desired = Target.position + Offset;
            transform.position = Vector3.Lerp(transform.position, desired, 1f - Mathf.Exp(-Follow * Time.deltaTime));
            transform.LookAt(Target.position + Vector3.up * 1.2f);
        }
    }
}
