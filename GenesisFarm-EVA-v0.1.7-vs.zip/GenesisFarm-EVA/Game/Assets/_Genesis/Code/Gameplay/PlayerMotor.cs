using Genesis.Core;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Gameplay
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerMotor : MonoBehaviour
    {
        public float MoveSpeed = 5f;
        public float RotateSpeed = 12f;
        public VerticalSliceRuntime Runtime { get; set; }
        private CharacterController _controller;

        private void Awake() => _controller = GetComponent<CharacterController>();

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            var input = Vector2.zero;
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y += 1;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y -= 1;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x += 1;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x -= 1;
            if (input.sqrMagnitude <= .01f) return;
            input.Normalize();
            var move = new Vector3(input.x, 0, input.y);
            _controller.SimpleMove(move * MoveSpeed);
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move), RotateSpeed * Time.deltaTime);
            if (Runtime != null)
            {
                Runtime.State.Player.X = Mathf.RoundToInt(transform.position.x);
                Runtime.State.Player.Y = Mathf.RoundToInt(transform.position.z);
            }
        }
    }
}
