using Genesis.Core;
using UnityEngine;

namespace Genesis.Farm
{
    public sealed class SoilPlotView : MonoBehaviour
    {
        public int GridX;
        public int GridY;
        public VerticalSliceRuntime Runtime { get; set; }
        private Renderer _renderer;
        private GameObject _crop;
        private float _refreshTimer;

        private void Awake() => _renderer = GetComponent<Renderer>();
        private void Update()
        {
            _refreshTimer -= Time.deltaTime;
            if (_refreshTimer > 0f) return;
            _refreshTimer = .25f;
            Refresh();
        }

        public void Refresh()
        {
            if (Runtime == null) return;
            var p = Runtime.PlotAt(GridX, GridY);
            if (p == null) return;
            if (_renderer != null)
            {
                var c = p.Tilled ? new Color(.30f, .18f, .08f) : new Color(.42f, .28f, .10f);
                if (p.Watered) c *= .65f;
                _renderer.material.color = c;
            }
            if (!p.Planted)
            {
                if (_crop != null) Destroy(_crop);
                _crop = null;
                return;
            }
            if (_crop == null)
            {
                _crop = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                _crop.name = "RadishCrop";
                _crop.transform.SetParent(transform, false);
                var collider = _crop.GetComponent<Collider>(); if (collider != null) collider.enabled = false;
            }
            _crop.transform.localPosition = Vector3.up * .35f;
            var size = p.Stage == 1 ? .25f : p.Stage == 2 ? .42f : .60f;
            _crop.transform.localScale = new Vector3(size, size * .8f, size);
            _crop.GetComponent<Renderer>().material.color = p.Ready ? new Color(.88f, .22f, .12f) : new Color(.20f, .65f, .20f);
        }
    }
}
