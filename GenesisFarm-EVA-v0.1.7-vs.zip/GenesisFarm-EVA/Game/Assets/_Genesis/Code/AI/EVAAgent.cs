using System.Linq;
using Genesis.Core;
using UnityEngine;

namespace Genesis.AI
{
    public sealed class EVAAgent : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public Transform Player { get; set; }
        public float MoveSpeed = 3.3f;
        private float _thinkTimer;

        private void Update()
        {
            if (Runtime == null) return;
            Runtime.State.Eva.X = Mathf.RoundToInt(transform.position.x);
            Runtime.State.Eva.Y = Mathf.RoundToInt(transform.position.z);
            _thinkTimer -= Time.deltaTime;
            if (_thinkTimer > 0) return;
            _thinkTimer = .35f;
            Think();
        }

        private void Think()
        {
            var s = Runtime.State;
            var dry = s.Plots.Where(p => p.Planted && !p.Watered && !p.Ready)
                .OrderBy(p => Runtime.Distance(s.Eva.X, s.Eva.Y, p.X, p.Y)).FirstOrDefault();

            if (s.Eva.Sleepiness >= .92f || s.Eva.Energy <= 15f)
            {
                SetBehavior("Resting", "Sleep");
                MoveToward(new Vector3(3, 0, 3));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, 3, 3) <= 1)
                {
                    s.Eva.Energy = Mathf.Min(100f, s.Eva.Energy + 35f);
                    s.Eva.Sleepiness = Mathf.Max(0f, s.Eva.Sleepiness - .55f);
                    s.AddEvent("EVARested", "home");
                }
                return;
            }

            if (s.Chicken.Owned && s.Chicken.Hunger >= .6f)
            {
                SetBehavior("Planning", "FeedChicken");
                if (s.Inventory.Feed <= 0)
                {
                    SetBehavior("MovingToShop", "FeedChicken");
                    MoveToward(new Vector3(21, 0, 5));
                    if (Runtime.Distance(s.Eva.X, s.Eva.Y, 21, 5) <= 1)
                    {
                        SetBehavior("BuyingFeed", "FeedChicken");
                        if (!Runtime.BuyFeed("eva")) SetBehavior("Blocked", "FeedChickenBlockedNoCoin");
                    }
                    return;
                }
                SetBehavior("MovingToCoop", "FeedChicken");
                MoveToward(new Vector3(15, 0, 5));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, 15, 5) <= 1)
                {
                    SetBehavior("Feeding", "FeedChicken");
                    Runtime.FeedChicken("eva");
                }
                return;
            }

            if (s.Eva.KnowsWater && dry != null)
            {
                SetBehavior("Planning", "WaterCrops");
                if (s.Inventory.WateringCanWater <= 0)
                {
                    SetBehavior("MovingToWell", "WaterCrops");
                    MoveToward(new Vector3(2, 0, 10));
                    if (Runtime.Distance(s.Eva.X, s.Eva.Y, 2, 10) <= 1)
                    {
                        s.Inventory.WateringCanWater = 20;
                        s.AddEvent("EVAFillWateringCan", "farm_well");
                    }
                    return;
                }
                SetBehavior("MovingToCrop", "WaterCrops");
                MoveToward(new Vector3(dry.X, 0, dry.Y));
                if (Runtime.Distance(s.Eva.X, s.Eva.Y, dry.X, dry.Y) <= 1)
                {
                    SetBehavior("Watering", "WaterCrops");
                    Runtime.Water(dry.X, dry.Y, "eva");
                }
                return;
            }

            SetBehavior("Following", "FollowPlayer");
            if (Player != null && Vector3.Distance(transform.position, Player.position) > 3f) MoveToward(Player.position);
        }

        private void SetBehavior(string behavior, string goal)
        {
            Runtime.State.Eva.BehaviorState = behavior;
            Runtime.State.Eva.CurrentGoal = goal;
        }

        private void MoveToward(Vector3 target)
        {
            target.y = transform.position.y;
            var before = transform.position;
            transform.position = Vector3.MoveTowards(transform.position, target, MoveSpeed * .35f);
            var dir = transform.position - before;
            if (dir.sqrMagnitude > .01f) transform.rotation = Quaternion.LookRotation(dir.normalized);
        }
    }
}
