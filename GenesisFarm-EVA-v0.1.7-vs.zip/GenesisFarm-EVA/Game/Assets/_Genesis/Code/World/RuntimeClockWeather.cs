using Genesis.Core;
using UnityEngine;

namespace Genesis.World
{
    public sealed class RuntimeClockWeather : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public Light Sun { get; set; }
        public float RealSecondsPerGameMinute = .5f;
        private float _accumulator;

        private void Update()
        {
            if (Runtime == null) return;
            _accumulator += Time.deltaTime;
            if (_accumulator < RealSecondsPerGameMinute) { RefreshLight(); return; }
            var minutes = Mathf.FloorToInt(_accumulator / RealSecondsPerGameMinute);
            _accumulator -= minutes * RealSecondsPerGameMinute;
            Runtime.AdvanceMinutes(minutes);
            var s = Runtime.State;
            s.Eva.Sleepiness = Mathf.Clamp01(s.Eva.Sleepiness + minutes / 1800f);
            s.Eva.Hunger = Mathf.Clamp01(s.Eva.Hunger + minutes / 2400f);
            s.Eva.Energy = Mathf.Max(0f, s.Eva.Energy - minutes / 45f);
            if (s.Chicken.Owned) s.Chicken.Hunger = Mathf.Clamp01(s.Chicken.Hunger + minutes / 2880f);
            RefreshLight();
        }

        private void RefreshLight()
        {
            if (Sun == null || Runtime == null) return;
            var hour = Runtime.State.Minute / 60f;
            var daylight = Mathf.Clamp01(Mathf.Sin((hour - 6f) / 12f * Mathf.PI));
            Sun.intensity = Mathf.Lerp(.18f, 1.15f, daylight);
            Sun.transform.rotation = Quaternion.Euler(Mathf.Lerp(8f, 70f, daylight), -30f, 0f);
            RenderSettings.ambientIntensity = Mathf.Lerp(.35f, 1f, daylight);
        }
    }
}
