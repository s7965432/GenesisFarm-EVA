using Genesis.AI;
using Genesis.Animals;
using Genesis.Core;
using Genesis.Farm;
using Genesis.Gameplay;
using Genesis.Interaction;
using Genesis.Persistence;
using Genesis.UI;
using UnityEngine;

namespace Genesis.World
{
    [DefaultExecutionOrder(-1000)]
    public sealed class VerticalSliceRuntimeBootstrap : MonoBehaviour
    {
        private VerticalSliceRuntime _runtime;
        private JsonSaveService _save;
        private SoilPlotView[] _plots;
        private GameObject _player;
        private GameObject _eva;

        private void Awake()
        {
            if (FindFirstObjectByType<GameBootstrap>() == null) gameObject.AddComponent<GameBootstrap>();
            _runtime = new VerticalSliceRuntime();
            _save = new JsonSaveService();
            BuildWorld();
        }

        private void BuildWorld()
        {
            MakeGround();
            MakeLandmark("Home", new Vector3(3, .75f, 3), new Vector3(2.5f, 1.5f, 2.5f), new Color(.72f, .53f, .33f));
            MakeLandmark("Well", new Vector3(2, .5f, 10), new Vector3(1.2f, 1f, 1.2f), new Color(.25f, .55f, .85f));
            MakeLandmark("Coop", new Vector3(15, .65f, 5), new Vector3(2.5f, 1.3f, 2.2f), new Color(.76f, .55f, .22f));
            MakeLandmark("TownShop", new Vector3(21, 1f, 5), new Vector3(3f, 2f, 3f), new Color(.60f, .45f, .70f));
            var road = MakeLandmark("TownRoad", new Vector3(20.5f, .02f, 8), new Vector3(6f, .04f, 15f), new Color(.48f, .44f, .40f));
            road.GetComponent<Collider>().enabled = false;

            foreach (var p in _runtime.State.Plots)
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = p.Id;
                go.transform.position = new Vector3(p.X, .08f, p.Y);
                go.transform.localScale = new Vector3(.92f, .16f, .92f);
                var view = go.AddComponent<SoilPlotView>(); view.GridX = p.X; view.GridY = p.Y; view.Runtime = _runtime; view.Refresh();
            }
            _plots = FindObjectsByType<SoilPlotView>(FindObjectsSortMode.None);

            _player = MakeActor("Player", new Vector3(3, .9f, 4), new Color(.20f, .45f, .95f));
            var primitiveCollider = _player.GetComponent<Collider>(); if (primitiveCollider != null) Destroy(primitiveCollider);
            var controller = _player.AddComponent<CharacterController>(); controller.height = 1.8f; controller.radius = .35f; controller.center = Vector3.zero;
            var motor = _player.AddComponent<PlayerMotor>(); motor.Runtime = _runtime;
            var interactor = _player.AddComponent<PlayerInteractor>(); interactor.Runtime = _runtime;

            _eva = MakeActor("EVA", new Vector3(5, .9f, 4), new Color(.95f, .55f, .85f));
            var agent = _eva.AddComponent<EVAAgent>(); agent.Runtime = _runtime; agent.Player = _player.transform;

            var chicken = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            chicken.name = "Chicken"; chicken.transform.position = new Vector3(15, .45f, 5.5f); chicken.transform.localScale = new Vector3(.6f, .7f, .6f);
            var chickenView = chicken.AddComponent<ChickenView>(); chickenView.Runtime = _runtime;

            var camGo = new GameObject("Main Camera"); camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>(); cam.fieldOfView = 55f;
            var follow = camGo.AddComponent<ThirdPersonCamera>(); follow.Target = _player.transform;

            var hudGo = new GameObject("VerticalSliceHUD");
            var hud = hudGo.AddComponent<VerticalSliceHUD>(); hud.Runtime = _runtime; hud.Interactor = interactor;
            hud.SaveRequested = () => { _save.Save(_runtime.State); hud.Message = "已存檔：" + _save.PathName; };
            hud.LoadRequested = () => { var loaded = _save.Load(); if (loaded == null) { hud.Message = "找不到存檔"; return; } _runtime.ReplaceState(loaded); SyncViews(); hud.Message = "已讀檔"; };

            var lightGo = new GameObject("Sun"); var light = lightGo.AddComponent<Light>(); light.type = LightType.Directional; light.intensity = 1.1f; lightGo.transform.rotation = Quaternion.Euler(50, -30, 0);
            var clock = gameObject.AddComponent<RuntimeClockWeather>(); clock.Runtime = _runtime; clock.Sun = light;
            var verifier = gameObject.AddComponent<UnityVerticalSliceVerifier>(); verifier.Runtime = _runtime; hud.Verifier = verifier;
            var scenario = gameObject.AddComponent<UnityVerticalSliceScenarioRunner>(); scenario.Runtime = _runtime; scenario.SyncViewsRequested = SyncViews; hud.Scenario = scenario;
        }

        private void MakeGround()
        {
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "WorldGround";
            ground.transform.position = new Vector3(11.5f, 0, 7.5f);
            ground.transform.localScale = new Vector3(2.4f, 1, 1.6f);
            ground.GetComponent<Renderer>().material.color = new Color(.34f, .62f, .28f);
        }

        private GameObject MakeLandmark(string name, Vector3 position, Vector3 scale, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube); go.name = name; go.transform.position = position; go.transform.localScale = scale; go.GetComponent<Renderer>().material.color = color; return go;
        }

        private GameObject MakeActor(string name, Vector3 position, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule); go.name = name; go.transform.position = position; go.GetComponent<Renderer>().material.color = color; return go;
        }

        private void SyncViews()
        {
            _player.transform.position = new Vector3(_runtime.State.Player.X, .9f, _runtime.State.Player.Y);
            _eva.transform.position = new Vector3(_runtime.State.Eva.X, .9f, _runtime.State.Eva.Y);
            foreach (var plot in _plots) plot.Refresh();
        }
    }
}
