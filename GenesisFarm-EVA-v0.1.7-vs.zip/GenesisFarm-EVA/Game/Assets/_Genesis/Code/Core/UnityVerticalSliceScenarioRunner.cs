using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Genesis.Persistence;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Core
{
    public sealed class UnityVerticalSliceScenarioRunner : MonoBehaviour
    {
        public static readonly string[] Nodes =
        {
            "BOOT","CREATE_WORLD","CREATE_PLAYER","CREATE_EVA","ENTER_FARM","TILL_SOIL","PLANT_RADISH",
            "PLAYER_DEMO_WATER_1","EVA_OBSERVE_1","PLAYER_DEMO_WATER_2","EVA_LEARN_WATER","EVA_AUTONOMOUS_WATER",
            "CROP_MATURE","FIRST_SHARED_HARVEST","CORE_MEMORY","TRAVEL_TOWN","SHOP_TRANSACTION","GET_CHICKEN",
            "CHICKEN_HUNGER","EVA_FEED_GOAL","EVA_PLAN_FEED","ACQUIRE_FEED","TRAVEL_COOP","FEED_CHICKEN",
            "ANIMAL_STATE_CHANGED","EVA_EXPERIENCE_MEMORY","EVENING_REST","DIARY","AUTOSAVE","EXIT","OFFLINE_SIM",
            "RESTART","WORLD_RESTORED","MEMORY_PERSISTED","GROUNDED_DIALOGUE"
        };

        public VerticalSliceRuntime Runtime { get; set; }
        public Action SyncViewsRequested { get; set; }
        public string LastReport { get; private set; } = "F7: Run Unity Vertical Slice Scenario";
        public string CurrentNode { get; private set; } = "IDLE";
        public bool IsRunning { get; private set; }
        public int Passed { get; private set; }
        public int Total => Nodes.Length;

        private readonly List<string> _lines = new();
        private JsonSaveService _save;
        private string _scenarioPath;

        private void Awake()
        {
            _save = new JsonSaveService();
            _scenarioPath = Path.Combine(Application.temporaryCachePath, "genesis-vs-scenario-0.1.7.json");
        }

        private void Update()
        {
            if (!IsRunning && Keyboard.current?.f7Key.wasPressedThisFrame == true)
                StartCoroutine(RunScenario());
        }

        public IEnumerator RunScenario()
        {
            IsRunning = true;
            Passed = 0;
            _lines.Clear();
            if (File.Exists(_scenarioPath)) File.Delete(_scenarioPath);
            Require(Runtime != null, "runtime missing");
            Runtime.ReplaceState(WorldRuntimeState.CreateFresh());
            Sync();

            MemoryRuntimeState feedMemory = null;
            var savedDay = 0;
            try
            {
                Check("BOOT", Runtime.State.Version == GameBootstrap.Version, GameBootstrap.Version); yield return Tick();
                Check("CREATE_WORLD", Has("WorldCreated")); yield return Tick();
                Check("CREATE_PLAYER", Runtime.State.Player != null && Has("PlayerCreated")); yield return Tick();
                Check("CREATE_EVA", Runtime.State.Eva != null && Has("EVACreated") && Runtime.State.Eva.Memories.Any(m => m.Type == "EVA_BIRTH")); yield return Tick();
                Check("ENTER_FARM", Has("FarmEntered")); yield return Tick();

                Runtime.SetPlayerGrid(7, 5); Runtime.SetEVAGrid(7, 5); Sync();
                Check("TILL_SOIL", Runtime.Till(7, 6)); yield return Tick();
                Check("PLANT_RADISH", Runtime.Plant(7, 6)); yield return Tick();
                Check("PLAYER_DEMO_WATER_1", Runtime.Water(7, 6, "player")); yield return Tick();
                Check("EVA_OBSERVE_1", Has("ObservationEvent") && !Runtime.State.Eva.KnowsWater); yield return Tick();

                Runtime.SetPlayerGrid(8, 5); Runtime.SetEVAGrid(8, 5); Sync();
                Require(Runtime.Till(8, 6), "second till failed");
                Require(Runtime.Plant(8, 6), "second plant failed");
                Check("PLAYER_DEMO_WATER_2", Runtime.Water(8, 6, "player")); yield return Tick();
                Check("EVA_LEARN_WATER", Runtime.State.Eva.KnowsWater && Has("KnowledgeLearned")); yield return Tick();

                Runtime.AdvanceDay();
                var dry = Runtime.State.Plots.FirstOrDefault(p => p.Planted && !p.Watered && !p.Ready);
                Require(dry != null, "no dry crop for EVA");
                Runtime.SetEVAGrid(dry.X, dry.Y - 1); Sync();
                Check("EVA_AUTONOMOUS_WATER", Runtime.Water(dry.X, dry.Y, "eva") && Has("CropWatered", "eva")); yield return Tick();

                Runtime.AdvanceDay();
                var ripe = Runtime.State.Plots.FirstOrDefault(p => p.Ready);
                Check("CROP_MATURE", ripe != null && ripe.Stage == 3); yield return Tick();
                Runtime.SetPlayerGrid(ripe.X, ripe.Y - 1); Runtime.SetEVAGrid(ripe.X, ripe.Y - 1); Sync();
                Check("FIRST_SHARED_HARVEST", Runtime.Harvest(ripe.X, ripe.Y)); yield return Tick();
                var harvestMemory = Runtime.State.Eva.Memories.FirstOrDefault(m => m.Type == "FIRST_HARVEST");
                Check("CORE_MEMORY", harvestMemory != null && harvestMemory.Core && !string.IsNullOrEmpty(harvestMemory.EventId)); yield return Tick();

                Runtime.TravelPlayer(21, 5); Sync();
                Check("TRAVEL_TOWN", Has("RegionEntered", "player:Town")); yield return Tick();
                Check("SHOP_TRANSACTION", Runtime.BuyChicken()); yield return Tick();
                Check("GET_CHICKEN", Runtime.State.Chicken.Owned); yield return Tick();
                Runtime.State.Inventory.Feed = 0; Runtime.State.Chicken.Hunger = .90f;
                Check("CHICKEN_HUNGER", Runtime.State.Chicken.Hunger >= .6f); yield return Tick();

                var plan = Runtime.BuildFeedChickenPlan();
                Check("EVA_FEED_GOAL", Has("EVAGoalSelected", "feed")); yield return Tick();
                Check("EVA_PLAN_FEED", string.Join(",", plan) == "move,buy_feed,move,feed" && Has("EVAPlanBuilt", "feed:move,buy_feed,move,feed")); yield return Tick();
                var coinBefore = Runtime.State.Inventory.Coin;
                Check("ACQUIRE_FEED", Runtime.ExecuteFeedChickenPlanForScenario() && Runtime.State.Inventory.Coin == coinBefore - 30 && Has("ShopTransaction", "eva:buy:feed")); yield return Tick();
                Check("TRAVEL_COOP", Has("RegionEntered", "eva:Farm") && Runtime.Distance(Runtime.State.Eva.X, Runtime.State.Eva.Y, 15, 5) <= 1); yield return Tick();
                Check("FEED_CHICKEN", Has("AnimalFed", "eva:chicken")); yield return Tick();
                Check("ANIMAL_STATE_CHANGED", Runtime.State.Chicken.Hunger < .2f && Runtime.State.Chicken.LastFedBy == "eva"); yield return Tick();
                feedMemory = Runtime.State.Eva.Memories.FirstOrDefault(m => m.Type == "FIRST_SELF_FEED_CHICKEN");
                Check("EVA_EXPERIENCE_MEMORY", Runtime.State.Eva.AnimalCareXp >= 10 && feedMemory != null && !string.IsNullOrEmpty(feedMemory.EventId)); yield return Tick();

                Runtime.TravelPlayer(3, 3); Sync();
                Check("EVENING_REST", Runtime.SleepPlayer()); yield return Tick();
                var diary = Runtime.GenerateDiary();
                Check("DIARY", diary != null && diary.EventIds != null && diary.EventIds.Count > 0); yield return Tick();

                Runtime.State.AddEvent("AutosaveCompleted", "scenario");
                _save.Save(Runtime.State, _scenarioPath);
                Check("AUTOSAVE", File.Exists(_scenarioPath) && Has("AutosaveCompleted")); yield return Tick();
                savedDay = Runtime.State.Day;
                Pass("EXIT", "simulated player process exit after file persistence"); yield return Tick();

                var restored = _save.Load(_scenarioPath);
                Require(restored != null, "scenario save could not reload");
                Runtime.ReplaceState(restored); Sync();
                Check("OFFLINE_SIM", Runtime.ApplyOfflineMinutes(120, "UNITY-VS-OFFLINE-120")); yield return Tick();
                Runtime.State.AddEvent("WorldResumed", "scenario");
                Check("RESTART", Has("SaveLoaded") && Has("WorldResumed")); yield return Tick();
                Check("WORLD_RESTORED", Runtime.State.Day == savedDay && Runtime.State.Chicken.Owned && Has("WorldStateRestored")); yield return Tick();
                Check("MEMORY_PERSISTED", Runtime.State.Eva.Memories.Any(m => m.Type == "FIRST_HARVEST") && Runtime.State.Eva.Memories.Any(m => m.Type == "FIRST_SELF_FEED_CHICKEN")); yield return Tick();
                var speech = Runtime.TalkAboutRecentMemory();
                Check("GROUNDED_DIALOGUE", feedMemory != null && speech.Contains(feedMemory.EventId) && speech.Contains("第一次自己買了飼料"), speech); yield return Tick();

                var before = Runtime.State.Offline.TotalMinutes;
                Require(!Runtime.ApplyOfflineMinutes(120, "UNITY-VS-OFFLINE-120"), "duplicate offline txn was accepted");
                Require(Runtime.State.Offline.TotalMinutes == before, "duplicate offline minutes changed total");
                LastReport = $"UNITY_VS_0_1_7_SCENARIO_PASS {Passed}/{Total} day={Runtime.State.Day} offline={Runtime.State.Offline.TotalMinutes} duplicateGuard=true";
                Debug.Log(LastReport + "\n" + string.Join("\n", _lines));
            }
            catch (Exception ex)
            {
                LastReport = $"UNITY_VS_0_1_7_SCENARIO_FAIL node={CurrentNode} passed={Passed}/{Total}: {ex.Message}";
                Debug.LogError(LastReport + "\n" + string.Join("\n", _lines));
            }
            finally
            {
                IsRunning = false;
                Sync();
            }
        }

        private bool Has(string type, string detailContains = null)
        {
            return Runtime.State.Events.Any(e => e.Type == type && (detailContains == null || (e.Detail != null && e.Detail.Contains(detailContains))));
        }

        private void Check(string id, bool condition, string detail = "")
        {
            CurrentNode = id;
            if (!condition) throw new InvalidOperationException("VS_NODE_FAIL:" + id + (string.IsNullOrEmpty(detail) ? "" : ":" + detail));
            Pass(id, detail);
        }

        private void Pass(string id, string detail = "")
        {
            CurrentNode = id;
            Passed++;
            _lines.Add("PASS " + id + (string.IsNullOrEmpty(detail) ? "" : " :: " + detail));
            LastReport = $"UNITY VS Scenario {Passed}/{Total} — {id}";
        }

        private static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        private object Tick()
        {
            Sync();
            return new WaitForSecondsRealtime(.025f);
        }

        private void Sync() => SyncViewsRequested?.Invoke();
    }
}
