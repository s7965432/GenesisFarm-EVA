using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Core
{
    public sealed class UnityVerticalSliceVerifier : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public string LastReport { get; private set; } = "F8: Unity Runtime Verify";

        private void Update()
        {
            if (Keyboard.current?.f8Key.wasPressedThisFrame == true) Run();
        }

        public bool Run()
        {
            if (Runtime == null) return Fail("runtime missing");
            var s = Runtime.State;
            if (s.Plots.Count != 12) return Fail("plot count");
            if (s.Player == null || s.Eva == null || s.Inventory == null || s.Chicken == null) return Fail("state domain missing");
            if (s.Events.Count == 0 || !s.Events.Any(e => e.Type == "WorldCreated")) return Fail("world event missing");
            if (string.IsNullOrEmpty(s.Eva.BehaviorState)) return Fail("eva behavior missing");
            LastReport = $"UNITY_RUNTIME_VERIFY_PASS day={s.Day} time={s.Minute/60:00}:{s.Minute%60:00} plots={s.Plots.Count} events={s.Events.Count}";
            Debug.Log(LastReport);
            return true;
        }

        private bool Fail(string reason)
        {
            LastReport = "UNITY_RUNTIME_VERIFY_FAIL: " + reason;
            Debug.LogError(LastReport);
            return false;
        }
    }
}
