using System;
using System.Collections.Generic;

namespace Genesis.Core
{
    [Serializable]
    public sealed class WorldRuntimeState
    {
        public string Version = GameBootstrap.Version;
        public int Day = 1;
        public int Minute = 8 * 60;
        public string Weather = "Clear";
        public PlayerRuntimeState Player = new();
        public EVARuntimeState Eva = new();
        public InventoryRuntimeState Inventory = new();
        public ChickenRuntimeState Chicken = new();
        public OfflineRuntimeState Offline = new();
        public List<PlotRuntimeState> Plots = new();
        public List<RuntimeEvent> Events = new();
        public List<DiaryRuntimeState> Diary = new();
        public int EventSequence;

        public static WorldRuntimeState CreateFresh()
        {
            var s = new WorldRuntimeState();
            s.Player.X = 3; s.Player.Y = 4;
            s.Eva.X = 5; s.Eva.Y = 4;
            s.Inventory.RadishSeed = 8;
            s.Inventory.Coin = 500;
            s.Inventory.WateringCanWater = 20;
            for (var y = 6; y <= 8; y++)
                for (var x = 7; x <= 10; x++)
                    s.Plots.Add(new PlotRuntimeState { Id = $"PLOT_{x}_{y}", X = x, Y = y });
            s.AddEvent("WorldCreated", "WORLD-VS-001");
            s.AddEvent("PlayerCreated", "player");
            var evaCreated = s.AddEvent("EVACreated", "eva");
            s.Eva.Memories.Add(new MemoryRuntimeState
            {
                Id = "MEM-EVA-BIRTH", Type = "EVA_BIRTH", EventId = evaCreated.Id,
                Core = true, Day = 1, Summary = "我記得自己在這座農場醒來。"
            });
            s.AddEvent("MemoryCreated", "MEM-EVA-BIRTH:" + evaCreated.Id);
            s.AddEvent("FarmEntered", "player+eva");
            return s;
        }

        public RuntimeEvent AddEvent(string type, string detail)
        {
            var e = new RuntimeEvent
            {
                Id = $"EVT-{++EventSequence}",
                Day = Day,
                Minute = Minute,
                Type = type,
                Detail = detail
            };
            Events.Add(e);
            return e;
        }
    }

    [Serializable] public sealed class PlayerRuntimeState { public int X; public int Y; public float Energy = 100f; }
    [Serializable] public sealed class EVARuntimeState
    {
        public int X; public int Y;
        public float Energy = 92f;
        public float Hunger = .15f;
        public float Sleepiness = .10f;
        public float WaterKnowledge;
        public bool KnowsWater;
        public float Confidence = .10f;
        public string CurrentGoal = "Observe player";
        public string BehaviorState = "Observing";
        public int FarmingXp;
        public int AnimalCareXp;
        public List<MemoryRuntimeState> Memories = new();
    }
    [Serializable] public sealed class InventoryRuntimeState { public int RadishSeed; public int Radish; public int Feed; public int Coin; public int WateringCanWater; }
    [Serializable] public sealed class ChickenRuntimeState { public bool Owned; public float Hunger; public int FedCount; public int Eggs; public string LastFedBy; }
    [Serializable] public sealed class OfflineRuntimeState { public int TotalMinutes; public string LastTransactionId = ""; }
    [Serializable] public sealed class PlotRuntimeState { public string Id; public int X; public int Y; public bool Tilled; public bool Planted; public bool Watered; public float Growth; public int Stage; public bool Ready; }
    [Serializable] public sealed class RuntimeEvent { public string Id; public int Day; public int Minute; public string Type; public string Detail; }
    [Serializable] public sealed class MemoryRuntimeState { public string Id; public string Type; public string EventId; public bool Core; public int Day; public string Summary; }
    [Serializable] public sealed class DiaryRuntimeState { public int Day; public string Text; public List<string> EventIds = new(); }
}
