using Genesis.Core;
using Genesis.Farm;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Interaction
{
    public sealed class PlayerInteractor : MonoBehaviour
    {
        public float Range = 2.4f;
        public VerticalSliceRuntime Runtime { get; set; }
        public string SelectedTool = "hoe";
        public string LastMessage { get; private set; } = "";

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null || Runtime == null) return;
            if (keyboard.digit1Key.wasPressedThisFrame) SelectedTool = "hoe";
            if (keyboard.digit2Key.wasPressedThisFrame) SelectedTool = "seed";
            if (keyboard.digit3Key.wasPressedThisFrame) SelectedTool = "water";
            if (keyboard.digit4Key.wasPressedThisFrame) SelectedTool = "harvest";
            if (keyboard.eKey.wasPressedThisFrame) Interact();
        }

        private void Interact()
        {
            var ray = new Ray(transform.position + Vector3.up * 1.1f, transform.forward);
            if (!Physics.Raycast(ray, out var hit, Range)) { LastMessage = "前方沒有可互動物件"; return; }
            var plot = hit.collider.GetComponentInParent<SoilPlotView>();
            if (plot != null)
            {
                var ok = SelectedTool switch
                {
                    "hoe" => Runtime.Till(plot.GridX, plot.GridY),
                    "seed" => Runtime.Plant(plot.GridX, plot.GridY),
                    "water" => Runtime.Water(plot.GridX, plot.GridY, "player"),
                    "harvest" => Runtime.Harvest(plot.GridX, plot.GridY),
                    _ => false
                };
                LastMessage = ok ? "農地互動完成" : "目前不能執行這個農地動作";
                if (ok) plot.Refresh();
                return;
            }

            switch (hit.collider.gameObject.name)
            {
                case "Well":
                    LastMessage = Runtime.RefillPlayer() ? "水壺已補滿" : "需要靠近井";
                    break;
                case "TownShop":
                    if (!Runtime.State.Chicken.Owned) LastMessage = Runtime.BuyChicken() ? "買下第一隻雞" : "金幣不足或已擁有雞";
                    else LastMessage = Runtime.BuyFeed("player") ? "購買 3 份飼料" : "金幣不足";
                    break;
                case "Home":
                    LastMessage = Runtime.SleepPlayer() ? "休息到隔天早上" : "需要靠近家";
                    break;
                case "Coop":
                    if (Runtime.State.Chicken.Eggs > 0)
                    {
                        var eggs = Runtime.State.Chicken.Eggs;
                        Runtime.State.Chicken.Eggs = 0;
                        Runtime.State.AddEvent("EggsCollected", "player:" + eggs);
                        LastMessage = $"收取 {eggs} 顆蛋";
                    }
                    else LastMessage = "雞舍目前沒有蛋";
                    break;
                default:
                    LastMessage = "這個物件目前沒有互動";
                    break;
            }
        }
    }
}
