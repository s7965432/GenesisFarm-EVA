#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace Genesis.Editor
{
    public static class WindowsBuildMenu
    {
        private const string ScenePath = "Assets/_Genesis/Scenes/VerticalSlice.unity";
        private const string OutputPath = "Build/Windows/GenesisFarm-EVA.exe";

        [MenuItem("Genesis/Build Windows x64")]
        public static void BuildWindows()
        {
            if (!File.Exists(ScenePath)) VerticalSliceSceneBuilder.Build();
            Directory.CreateDirectory("Build/Windows");
            var options = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = OutputPath,
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
                throw new BuildFailedException($"Windows build failed: {report.summary.result} / {report.summary.totalErrors} errors");
            Debug.Log($"Genesis Farm EVA Windows build complete: {OutputPath} ({report.summary.totalSize} bytes)");
        }
    }
}
#endif
