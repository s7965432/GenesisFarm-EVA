#if UNITY_EDITOR
using Genesis.World;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Genesis.Editor
{
    public static class VerticalSliceSceneBuilder
    {
        private const string ScenePath = "Assets/_Genesis/Scenes/VerticalSlice.unity";

        [MenuItem("Genesis/Build Vertical Slice Scene")]
        public static void Build()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("GenesisVerticalSlice");
            root.AddComponent<VerticalSliceRuntimeBootstrap>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            Selection.activeGameObject = root;
            Debug.Log("Genesis Vertical Slice scene generated and added to Build Settings: " + ScenePath);
        }
    }
}
#endif
