# Genesis Farm: EVA — v0.1.7-vs

This package advances the project from browser-oracle validation toward a Unity-first playable Vertical Slice.

## v0.1.7 focus
- Unity Player now has an in-runtime full Vertical Slice Scenario Runner (`F7`).
- The runner executes the 35-node acceptance chain from a clean world through learning, farming, town trade, chicken care, diary, save/reload, offline simulation and grounded memory dialogue.
- Scenario save/reload uses a real temporary JSON file and does not overwrite the player's normal slot.
- Offline simulation now owns a transaction ledger and rejects duplicate transaction IDs.
- Unity runtime state now includes EVA birth core memory, evidence-linked diary entries, region-entered events and restore events.
- FeedChicken planning records the exact `move,buy_feed,move,feed` plan when feed is unavailable.
- Existing browser scenario remains the deterministic regression oracle and must stay green.

## Unity controls
- WASD / arrow keys: move
- 1 / 2 / 3 / 4: till / plant / water / harvest
- E: interact
- T: ask EVA about recent grounded memory
- F5 / F9: save / load player slot
- F7: run the full Unity Vertical Slice Scenario
- F8: verify current Unity runtime state

## Verification status
- Browser deterministic scenario: PASS 37/37.
- Duplicate offline transaction guard: PASS.
- Unity engineering/static checks: PASS.
- Unity Editor compile, Windows x64 executable launch, and Android device run: UNVERIFIED in this environment.
