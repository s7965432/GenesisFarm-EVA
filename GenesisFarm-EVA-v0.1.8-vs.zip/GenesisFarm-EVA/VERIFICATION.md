# Verification — 0.1.8-vs

## Browser deterministic oracle
Run:

```bash
cd Prototype
node --check core.mjs
node --check scenario.mjs
node --check game.js
node --check verify.mjs
node verify.mjs
```

Expected marker: `GENESIS_VS_0_1_8_VERIFY_PASS`
Expected: 37/37 checks, 35 named nodes, offline 120 minutes, duplicate offline transaction guarded.

## Unity runtime scenario
In a Unity Player or Play Mode:
- Press `F7`.
- The scenario resets to a clean world and runs all 35 named Vertical Slice nodes.
- It writes a scenario-only JSON file under `Application.temporaryCachePath`.
- It reloads that file, applies 120 offline minutes, confirms memory persistence and rejects re-applying the same offline transaction ID.

Expected runtime marker:
`UNITY_VS_0_1_8_SCENARIO_PASS 35/35 ... duplicateGuard=true`

`F8` remains the lightweight current-state verifier.

## PC presentation static gate
Run from package root:

```bash
python Tests/verify_unity_static.py
```

The gate checks required runtime/editor files, asmdef JSON, current version markers, PC-control implementation tokens, full-scenario marker and balanced C# braces.

## Environment limitation
Unity Editor is not installed in this execution environment. C# source can therefore be statically inspected but not truthfully marked as Unity-compiled or Windows-player-tested here.
