# Genesis Farm: EVA — v0.1.8-vs

This package moves the verified Vertical Slice from engineering proof toward a PC-playable presentation layer while keeping the deterministic acceptance chain intact.

## v0.1.8 focus
- Third-person movement is now camera-relative instead of fixed world-axis movement.
- Hold Shift to sprint; character facing smoothly follows movement direction.
- Camera supports RMB orbit, mouse-wheel zoom, pitch limits and collision shortening so it does not intentionally sit behind solid geometry.
- Interaction now maintains a focused target in front of the player, enforces physical range, and exposes contextual `[E]` prompts for plots, the well, home, coop and town shop.
- HUD adds a center reticle, bottom interaction card, player motion state, water amount and current region.
- EVA now has an in-world label showing her current Goal and BehaviorState, so autonomous decisions are observable without opening debug data.
- Farm/Town presentation now includes separate ground surfaces, a road, simple landmark roofs/details, region signs and invisible world-edge collision.
- Save/load still restores authoritative state and refreshes scene views.
- Unity F7 full Vertical Slice and browser deterministic oracle remain mandatory regression gates.

## Unity controls
- WASD / arrow keys: move relative to camera
- Shift: sprint
- Hold RMB + move mouse: orbit camera
- Mouse wheel: camera zoom
- 1 / 2 / 3 / 4: till / plant / water / harvest
- E: contextual interaction
- T: ask EVA about recent grounded memory
- F5 / F9: save / load player slot
- F7: run the full Unity Vertical Slice Scenario
- F8: verify current Unity runtime state

## Build path
Unity Editor menu:
- `Genesis > Build Vertical Slice Scene`
- `Genesis > Build Windows x64`

Windows target remains `Build/Windows/GenesisFarm-EVA.exe`.

## Verification status
- Browser deterministic scenario: PASS 37/37.
- 35 named acceptance nodes preserved.
- Duplicate offline transaction guard: PASS.
- Unity engineering/static gate: PASS.
- Unity Editor compile, Windows x64 executable launch, and Android device run: UNVERIFIED in this environment.
