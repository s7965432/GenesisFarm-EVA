using Genesis.AI;
using Genesis.Animals;
using Genesis.Core;
using Genesis.Farm;
using Genesis.Gameplay;
using Genesis.Interaction;
using Genesis.Persistence;
using Genesis.UI;
using UnityEngine;

namespace Genesis.World
{
    [DefaultExecutionOrder(-1000)]
    public sealed class VerticalSliceRuntimeBootstrap : MonoBehaviour
    {
        private VerticalSliceRuntime _runtime;
        private JsonSaveService _save;
        private SoilPlotView[] _plots;
        private GameObject _player;
        private GameObject _eva;

        private void Awake()
        {
            if (FindFirstObjectByType<GameBootstrap>() == null) gameObject.AddComponent<GameBootstrap>();
            _runtime = new VerticalSliceRuntime();
            _save = new JsonSaveService();
            BuildWorld();
        }

        private void BuildWorld()
        {
            MakeGround();
            MakeTownGround();
            MakeRoad();
            MakeWorldBoundary();

            var home = MakeLandmark("Home", new Vector3(3, .75f, 3), new Vector3(2.5f, 1.5f, 2.5f), new Color(.72f, .53f, .33f));
            AddRoof(home, new Color(.42f, .16f, .10f));
            var well = MakeLandmark("Well", new Vector3(2, .5f, 10), new Vector3(1.2f, 1f, 1.2f), new Color(.25f, .55f, .85f));
            AddTop(well, PrimitiveType.Cylinder, new Vector3(0, .72f, 0), new Vector3(1.05f, .12f, 1.05f), new Color(.18f, .34f, .50f));
            var coop = MakeLandmark("Coop", new Vector3(15, .65f, 5), new Vector3(2.5f, 1.3f, 2.2f), new Color(.76f, .55f, .22f));
            AddRoof(coop, new Color(.45f, .22f, .08f));
            var shop = MakeLandmark("TownShop", new Vector3(21, 1f, 5), new Vector3(3f, 2f, 3f), new Color(.60f, .45f, .70f));
            AddRoof(shop, new Color(.34f, .20f, .44f));

            MakeSign("FarmSign", new Vector3(16.8f, .75f, 8.3f), new Color(.52f, .34f, .16f));
            MakeSign("TownSign", new Vector3(18.4f, .75f, 8.3f), new Color(.36f, .28f, .16f));

            foreach (var p in _runtime.State.Plots)
            {
                var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                go.name = p.Id;
                go.transform.position = new Vector3(p.X, .08f, p.Y);
                go.transform.localScale = new Vector3(.92f, .16f, .92f);
                var view = go.AddComponent<SoilPlotView>();
                view.GridX = p.X;
                view.GridY = p.Y;
                view.Runtime = _runtime;
                view.Refresh();
            }
            _plots = FindObjectsByType<SoilPlotView>(FindObjectsSortMode.None);

            _player = MakeActor("Player", new Vector3(3, .9f, 4), new Color(.20f, .45f, .95f));
            var primitiveCollider = _player.GetComponent<Collider>();
            if (primitiveCollider != null) Destroy(primitiveCollider);
            var controller = _player.AddComponent<CharacterController>();
            controller.height = 1.8f;
            controller.radius = .35f;
            controller.center = Vector3.zero;
            controller.stepOffset = .28f;
            controller.slopeLimit = 50f;
            var motor = _player.AddComponent<PlayerMotor>();
            motor.Runtime = _runtime;
            var interactor = _player.AddComponent<PlayerInteractor>();
            interactor.Runtime = _runtime;
            AddActorHead(_player, new Color(.92f, .78f, .68f));

            _eva = MakeActor("EVA", new Vector3(5, .9f, 4), new Color(.95f, .55f, .85f));
            AddActorHead(_eva, new Color(.96f, .82f, .75f));
            var agent = _eva.AddComponent<EVAAgent>();
            agent.Runtime = _runtime;
            agent.Player = _player.transform;
            var status = _eva.AddComponent<EVAWorldStatus>();
            status.Runtime = _runtime;

            var chicken = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            chicken.name = "Chicken";
            chicken.transform.position = new Vector3(15, .45f, 5.5f);
            chicken.transform.localScale = new Vector3(.6f, .7f, .6f);
            chicken.GetComponent<Renderer>().material.color = new Color(.96f, .92f, .72f);
            var chickenView = chicken.AddComponent<ChickenView>();
            chickenView.Runtime = _runtime;

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.fieldOfView = 58f;
            cam.nearClipPlane = .08f;
            var follow = camGo.AddComponent<ThirdPersonCamera>();
            follow.Target = _player.transform;

            var hudGo = new GameObject("VerticalSliceHUD");
            var hud = hudGo.AddComponent<VerticalSliceHUD>();
            hud.Runtime = _runtime;
            hud.Interactor = interactor;
            hud.Motor = motor;
            hud.SaveRequested = () => { _save.Save(_runtime.State); hud.Message = "已存檔：" + _save.PathName; };
            hud.LoadRequested = () =>
            {
                var loaded = _save.Load();
                if (loaded == null) { hud.Message = "找不到存檔"; return; }
                _runtime.ReplaceState(loaded);
                SyncViews();
                hud.Message = "已讀檔並重建場景狀態";
            };

            var lightGo = new GameObject("Sun");
            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.1f;
            light.shadows = LightShadows.Soft;
            lightGo.transform.rotation = Quaternion.Euler(50, -30, 0);

            RenderSettings.ambientLight = new Color(.55f, .58f, .62f);
            var clock = gameObject.AddComponent<RuntimeClockWeather>();
            clock.Runtime = _runtime;
            clock.Sun = light;
            var verifier = gameObject.AddComponent<UnityVerticalSliceVerifier>();
            verifier.Runtime = _runtime;
            hud.Verifier = verifier;
            var scenario = gameObject.AddComponent<UnityVerticalSliceScenarioRunner>();
            scenario.Runtime = _runtime;
            scenario.SyncViewsRequested = SyncViews;
            hud.Scenario = scenario;
        }

        private void MakeGround()
        {
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "FarmGround";
            ground.transform.position = new Vector3(8.8f, 0, 7.5f);
            ground.transform.localScale = new Vector3(1.8f, 1, 1.6f);
            ground.GetComponent<Renderer>().material.color = new Color(.34f, .62f, .28f);
        }

        private void MakeTownGround()
        {
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "TownGround";
            ground.transform.position = new Vector3(20.8f, -.005f, 7.5f);
            ground.transform.localScale = new Vector3(.65f, 1, 1.6f);
            ground.GetComponent<Renderer>().material.color = new Color(.48f, .46f, .42f);
        }

        private void MakeRoad()
        {
            var road = GameObject.CreatePrimitive(PrimitiveType.Cube);
            road.name = "TownRoad";
            road.transform.position = new Vector3(17.8f, .025f, 8f);
            road.transform.localScale = new Vector3(7.5f, .05f, 2.1f);
            road.GetComponent<Renderer>().material.color = new Color(.52f, .47f, .40f);
            var collider = road.GetComponent<Collider>();
            if (collider != null) collider.enabled = false;
        }

        private void MakeWorldBoundary()
        {
            MakeInvisibleWall("NorthBoundary", new Vector3(11.5f, 1f, 16.35f), new Vector3(25f, 2f, .5f));
            MakeInvisibleWall("SouthBoundary", new Vector3(11.5f, 1f, -.35f), new Vector3(25f, 2f, .5f));
            MakeInvisibleWall("WestBoundary", new Vector3(-.35f, 1f, 8f), new Vector3(.5f, 2f, 17f));
            MakeInvisibleWall("EastBoundary", new Vector3(24.35f, 1f, 8f), new Vector3(.5f, 2f, 17f));
        }

        private void MakeInvisibleWall(string name, Vector3 position, Vector3 scale)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.position = position;
            go.transform.localScale = scale;
            var renderer = go.GetComponent<Renderer>();
            if (renderer != null) renderer.enabled = false;
        }

        private GameObject MakeLandmark(string name, Vector3 position, Vector3 scale, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.position = position;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().material.color = color;
            return go;
        }

        private void AddRoof(GameObject parent, Color color)
        {
            var roof = GameObject.CreatePrimitive(PrimitiveType.Cube);
            roof.name = parent.name + "Roof";
            roof.transform.SetParent(parent.transform, false);
            roof.transform.localPosition = new Vector3(0, .62f, 0);
            roof.transform.localRotation = Quaternion.Euler(0, 0, 45f);
            roof.transform.localScale = new Vector3(.78f, .12f, 1.05f);
            roof.GetComponent<Renderer>().material.color = color;
            var c = roof.GetComponent<Collider>();
            if (c != null) c.enabled = false;
        }

        private void AddTop(GameObject parent, PrimitiveType type, Vector3 localPosition, Vector3 localScale, Color color)
        {
            var top = GameObject.CreatePrimitive(type);
            top.name = parent.name + "Top";
            top.transform.SetParent(parent.transform, false);
            top.transform.localPosition = localPosition;
            top.transform.localScale = localScale;
            top.GetComponent<Renderer>().material.color = color;
            var c = top.GetComponent<Collider>();
            if (c != null) c.enabled = false;
        }

        private void MakeSign(string name, Vector3 position, Color color)
        {
            var pole = GameObject.CreatePrimitive(PrimitiveType.Cube);
            pole.name = name;
            pole.transform.position = position;
            pole.transform.localScale = new Vector3(.12f, 1.5f, .12f);
            pole.GetComponent<Renderer>().material.color = color;
            var board = GameObject.CreatePrimitive(PrimitiveType.Cube);
            board.name = name + "Board";
            board.transform.SetParent(pole.transform, false);
            board.transform.localPosition = new Vector3(0, .32f, 0);
            board.transform.localScale = new Vector3(4.5f, .28f, 2.2f);
            board.GetComponent<Renderer>().material.color = color;
            var c = board.GetComponent<Collider>();
            if (c != null) c.enabled = false;
        }

        private GameObject MakeActor(string name, Vector3 position, Color color)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            go.name = name;
            go.transform.position = position;
            go.GetComponent<Renderer>().material.color = color;
            return go;
        }

        private void AddActorHead(GameObject actor, Color color)
        {
            var head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            head.name = actor.name + "Head";
            head.transform.SetParent(actor.transform, false);
            head.transform.localPosition = new Vector3(0, .72f, 0);
            head.transform.localScale = new Vector3(.62f, .62f, .62f);
            head.GetComponent<Renderer>().material.color = color;
            var c = head.GetComponent<Collider>();
            if (c != null) c.enabled = false;
        }

        private void SyncViews()
        {
            _player.transform.position = new Vector3(_runtime.State.Player.X, .9f, _runtime.State.Player.Y);
            _eva.transform.position = new Vector3(_runtime.State.Eva.X, .9f, _runtime.State.Eva.Y);
            foreach (var plot in _plots) plot.Refresh();
        }
    }
}
