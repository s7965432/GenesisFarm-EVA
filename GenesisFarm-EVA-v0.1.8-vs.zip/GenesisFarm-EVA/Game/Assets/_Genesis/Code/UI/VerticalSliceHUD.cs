using Genesis.Core;
using Genesis.Gameplay;
using Genesis.Interaction;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.UI
{
    public sealed class VerticalSliceHUD : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public PlayerInteractor Interactor { get; set; }
        public PlayerMotor Motor { get; set; }
        public string Message = "WASD移動｜Shift衝刺｜右鍵拖曳鏡頭｜滾輪縮放｜E互動｜1~4工具｜F5存 F9讀｜F7完整VS｜F8狀態驗證";
        public System.Action SaveRequested;
        public System.Action LoadRequested;
        public UnityVerticalSliceVerifier Verifier { get; set; }
        public UnityVerticalSliceScenarioRunner Scenario { get; set; }

        private GUIStyle _title;
        private GUIStyle _body;
        private GUIStyle _prompt;
        private GUIStyle _focus;

        private void Update()
        {
            var k = Keyboard.current;
            if (k == null) return;
            if (k.f5Key.wasPressedThisFrame) SaveRequested?.Invoke();
            if (k.f9Key.wasPressedThisFrame) LoadRequested?.Invoke();
            if (k.tKey.wasPressedThisFrame) Message = Runtime.TalkAboutRecentMemory();
        }

        private void EnsureStyles()
        {
            if (_title != null) return;
            _title = new GUIStyle(GUI.skin.label) { fontSize = 16, fontStyle = FontStyle.Bold };
            _title.normal.textColor = Color.white;
            _body = new GUIStyle(GUI.skin.label) { fontSize = 13 };
            _body.normal.textColor = Color.white;
            _prompt = new GUIStyle(GUI.skin.label) { fontSize = 15, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            _prompt.normal.textColor = Color.white;
            _focus = new GUIStyle(GUI.skin.label) { fontSize = 12, alignment = TextAnchor.MiddleCenter };
            _focus.normal.textColor = new Color(.92f, .92f, .92f);
        }

        private void OnGUI()
        {
            if (Runtime == null) return;
            EnsureStyles();
            var s = Runtime.State;

            GUI.Box(new Rect(12, 12, 595, 190), "");
            GUI.Label(new Rect(24, 20, 560, 24), "Genesis Farm: EVA  " + GameBootstrap.Version, _title);
            GUI.Label(new Rect(24, 48, 520, 20), $"Day {s.Day}  {s.Minute/60:00}:{s.Minute%60:00}  Weather: {s.Weather}  Region: {(s.Player.X >= 18 ? "Town" : "Farm")}", _body);
            GUI.Label(new Rect(24, 71, 520, 20), $"Coin {s.Inventory.Coin}  Seeds {s.Inventory.RadishSeed}  Radish {s.Inventory.Radish}  Feed {s.Inventory.Feed}  Water {s.Inventory.WateringCanWater}/20", _body);
            GUI.Label(new Rect(24, 94, 540, 20), $"EVA Goal: {s.Eva.CurrentGoal}  State: {s.Eva.BehaviorState}", _body);
            GUI.Label(new Rect(24, 117, 540, 20), $"Knowledge {s.Eva.WaterKnowledge:0.00}  Farming XP {s.Eva.FarmingXp}  AnimalCare XP {s.Eva.AnimalCareXp}", _body);
            GUI.Label(new Rect(24, 140, 540, 20), $"Tool: {Interactor?.SelectedTool ?? "-"}  Player: {(Motor != null && Motor.IsSprinting ? "Sprint" : Motor != null && Motor.IsMoving ? "Walk" : "Idle")}  Chicken: {(s.Chicken.Owned ? $"Hunger {s.Chicken.Hunger:0.00} Eggs {s.Chicken.Eggs}" : "not owned")}", _body);
            var interaction = Interactor != null && !string.IsNullOrEmpty(Interactor.LastMessage) ? Interactor.LastMessage : Message;
            GUI.Label(new Rect(24, 163, 560, 24), interaction, _body);

            DrawCrosshair();
            DrawInteractionPrompt();

            if (Verifier != null && !string.IsNullOrEmpty(Verifier.LastReport)) GUI.Label(new Rect(12, 208, 980, 22), Verifier.LastReport, _body);
            if (Scenario != null && !string.IsNullOrEmpty(Scenario.LastReport)) GUI.Label(new Rect(12, 232, 1180, 22), Scenario.LastReport, _body);
        }

        private void DrawCrosshair()
        {
            var x = Screen.width * .5f;
            var y = Screen.height * .5f;
            GUI.Label(new Rect(x - 10, y - 14, 20, 28), "+", _prompt);
        }

        private void DrawInteractionPrompt()
        {
            if (Interactor == null || string.IsNullOrEmpty(Interactor.FocusPrompt)) return;
            var width = 380f;
            var x = (Screen.width - width) * .5f;
            var y = Screen.height - 108f;
            GUI.Box(new Rect(x, y, width, 70f), "");
            GUI.Label(new Rect(x + 10, y + 8, width - 20, 20), Interactor.FocusName, _focus);
            GUI.Label(new Rect(x + 10, y + 30, width - 20, 28), Interactor.FocusPrompt, _prompt);
        }
    }
}
