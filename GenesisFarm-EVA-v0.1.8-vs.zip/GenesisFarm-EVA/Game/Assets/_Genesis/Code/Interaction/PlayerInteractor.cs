using System;
using System.Linq;
using Genesis.Core;
using Genesis.Farm;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.Interaction
{
    public sealed class PlayerInteractor : MonoBehaviour
    {
        public float Range = 3.1f;
        public float AimRadius = .12f;
        public VerticalSliceRuntime Runtime { get; set; }
        public string SelectedTool = "hoe";
        public string LastMessage { get; private set; } = "";
        public string FocusPrompt { get; private set; } = "";
        public string FocusName { get; private set; } = "";
        public Transform FocusTransform { get; private set; }

        private readonly RaycastHit[] _hits = new RaycastHit[24];
        private float _messageTimer;

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null || Runtime == null) return;
            if (keyboard.digit1Key.wasPressedThisFrame) SelectTool("hoe");
            if (keyboard.digit2Key.wasPressedThisFrame) SelectTool("seed");
            if (keyboard.digit3Key.wasPressedThisFrame) SelectTool("water");
            if (keyboard.digit4Key.wasPressedThisFrame) SelectTool("harvest");

            UpdateFocus();
            if (keyboard.eKey.wasPressedThisFrame) Interact();

            if (_messageTimer > 0f)
            {
                _messageTimer -= Time.deltaTime;
                if (_messageTimer <= 0f) LastMessage = "";
            }
        }

        private void SelectTool(string tool)
        {
            SelectedTool = tool;
            ShowMessage("已切換工具：" + ToolDisplayName(tool), 1.25f);
        }

        private void UpdateFocus()
        {
            FocusTransform = null;
            FocusName = "";
            FocusPrompt = "";

            var ray = new Ray(transform.position + Vector3.up * 1.05f, transform.forward);
            var count = Physics.SphereCastNonAlloc(ray, AimRadius, _hits, Range + 2f, ~0, QueryTriggerInteraction.Ignore);
            var candidate = _hits.Take(count)
                .Where(h => h.collider != null && !h.collider.transform.IsChildOf(transform))
                .OrderBy(h => h.distance)
                .FirstOrDefault(h => IsInteractable(h.collider));

            if (candidate.collider == null) return;
            var pointDistance = Vector3.Distance(transform.position, candidate.point);
            if (pointDistance > Range) return;

            FocusTransform = candidate.collider.transform;
            var plot = candidate.collider.GetComponentInParent<SoilPlotView>();
            if (plot != null)
            {
                FocusName = $"農地 ({plot.GridX},{plot.GridY})";
                FocusPrompt = $"[E] {ToolActionName(SelectedTool)}";
                return;
            }

            var rootName = ResolveRootName(candidate.collider.transform);
            FocusName = DisplayName(rootName);
            FocusPrompt = rootName switch
            {
                "Well" => "[E] 補滿水壺",
                "TownShop" => Runtime.State.Chicken.Owned ? "[E] 購買飼料（30）" : "[E] 購買雞（250）",
                "Home" => "[E] 睡到隔天早上",
                "Coop" => Runtime.State.Chicken.Eggs > 0 ? $"[E] 收取 {Runtime.State.Chicken.Eggs} 顆蛋" : "[E] 查看雞舍",
                _ => ""
            };
        }

        private bool IsInteractable(Collider collider)
        {
            if (collider.GetComponentInParent<SoilPlotView>() != null) return true;
            var name = ResolveRootName(collider.transform);
            return name == "Well" || name == "TownShop" || name == "Home" || name == "Coop";
        }

        private string ResolveRootName(Transform t)
        {
            var current = t;
            while (current != null)
            {
                if (current.name == "Well" || current.name == "TownShop" || current.name == "Home" || current.name == "Coop") return current.name;
                current = current.parent;
            }
            return t.name;
        }

        private void Interact()
        {
            if (FocusTransform == null)
            {
                ShowMessage("沒有鎖定可互動目標");
                return;
            }

            var plot = FocusTransform.GetComponentInParent<SoilPlotView>();
            if (plot != null)
            {
                var ok = SelectedTool switch
                {
                    "hoe" => Runtime.Till(plot.GridX, plot.GridY),
                    "seed" => Runtime.Plant(plot.GridX, plot.GridY),
                    "water" => Runtime.Water(plot.GridX, plot.GridY, "player"),
                    "harvest" => Runtime.Harvest(plot.GridX, plot.GridY),
                    _ => false
                };
                ShowMessage(ok ? $"{ToolActionName(SelectedTool)}完成" : "目前不能執行這個農地動作");
                if (ok) plot.Refresh();
                return;
            }

            switch (ResolveRootName(FocusTransform))
            {
                case "Well":
                    ShowMessage(Runtime.RefillPlayer() ? "水壺已補滿" : "需要再靠近井");
                    break;
                case "TownShop":
                    if (!Runtime.State.Chicken.Owned) ShowMessage(Runtime.BuyChicken() ? "買下第一隻雞" : "金幣不足或已擁有雞");
                    else ShowMessage(Runtime.BuyFeed("player") ? "購買 3 份飼料" : "金幣不足");
                    break;
                case "Home":
                    ShowMessage(Runtime.SleepPlayer() ? "休息到隔天早上" : "需要再靠近家");
                    break;
                case "Coop":
                    if (Runtime.State.Chicken.Eggs > 0)
                    {
                        var eggs = Runtime.State.Chicken.Eggs;
                        Runtime.State.Chicken.Eggs = 0;
                        Runtime.State.AddEvent("EggsCollected", "player:" + eggs);
                        ShowMessage($"收取 {eggs} 顆蛋");
                    }
                    else ShowMessage("雞舍目前沒有蛋");
                    break;
                default:
                    ShowMessage("這個物件目前沒有互動");
                    break;
            }
        }

        private void ShowMessage(string text, float duration = 2.2f)
        {
            LastMessage = text;
            _messageTimer = duration;
        }

        private static string ToolDisplayName(string tool) => tool switch
        {
            "hoe" => "鋤頭",
            "seed" => "白蘿蔔種子",
            "water" => "水壺",
            "harvest" => "收成",
            _ => tool
        };

        private static string ToolActionName(string tool) => tool switch
        {
            "hoe" => "耕地",
            "seed" => "播種",
            "water" => "澆水",
            "harvest" => "收成",
            _ => "互動"
        };

        private static string DisplayName(string rootName) => rootName switch
        {
            "Well" => "農場水井",
            "TownShop" => "小鎮商店",
            "Home" => "家",
            "Coop" => "雞舍",
            _ => rootName
        };
    }
}
