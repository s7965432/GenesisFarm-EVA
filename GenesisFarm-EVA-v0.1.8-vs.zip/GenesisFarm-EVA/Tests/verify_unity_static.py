from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "Game/Assets/_Genesis/Code"
EDITOR = ROOT / "Game/Assets/_Genesis/Editor"
VERSION = "0.1.8-vs"

required = [
    CODE / "Gameplay/PlayerMotor.cs",
    CODE / "Gameplay/ThirdPersonCamera.cs",
    CODE / "Interaction/PlayerInteractor.cs",
    CODE / "UI/VerticalSliceHUD.cs",
    CODE / "UI/EVAWorldStatus.cs",
    CODE / "World/VerticalSliceRuntimeBootstrap.cs",
    CODE / "Core/UnityVerticalSliceScenarioRunner.cs",
    EDITOR / "WindowsBuildMenu.cs",
    EDITOR / "VerticalSliceSceneBuilder.cs",
]

errors = []
for path in required:
    if not path.exists():
        errors.append(f"missing:{path.relative_to(ROOT)}")

for asmdef in [CODE / "Genesis.Runtime.asmdef", EDITOR / "Genesis.Editor.asmdef"]:
    try:
        json.loads(asmdef.read_text())
    except Exception as exc:
        errors.append(f"asmdef:{asmdef.name}:{exc}")

bootstrap = (CODE / "World/VerticalSliceRuntimeBootstrap.cs").read_text()
motor = (CODE / "Gameplay/PlayerMotor.cs").read_text()
camera = (CODE / "Gameplay/ThirdPersonCamera.cs").read_text()
interactor = (CODE / "Interaction/PlayerInteractor.cs").read_text()
hud = (CODE / "UI/VerticalSliceHUD.cs").read_text()
scenario = (CODE / "Core/UnityVerticalSliceScenarioRunner.cs").read_text()
game_bootstrap = (CODE / "Core/GameBootstrap.cs").read_text()

checks = {
    "version": VERSION in game_bootstrap,
    "camera_relative_move": "Camera.main" in motor and "SprintSpeed" in motor,
    "camera_orbit": "rightButton.isPressed" in camera and "scroll.ReadValue" in camera,
    "camera_collision": "SphereCastNonAlloc" in camera,
    "context_focus": "FocusPrompt" in interactor and "SphereCastNonAlloc" in interactor,
    "world_prompt": "DrawInteractionPrompt" in hud,
    "eva_world_status": "EVAWorldStatus" in bootstrap,
    "world_boundary": "MakeWorldBoundary" in bootstrap,
    "windows_build": "BuildTarget.StandaloneWindows64" in (EDITOR / "WindowsBuildMenu.cs").read_text(),
    "unity_scenario_version": "UNITY_VS_0_1_8_SCENARIO_PASS" in scenario,
}
for name, ok in checks.items():
    if not ok:
        errors.append("check:" + name)

for path in ROOT.glob("Game/Assets/_Genesis/**/*.cs"):
    text = path.read_text()
    stripped = re.sub(r'//.*|/\*.*?\*/|"(?:\\.|[^"\\])*"', '', text, flags=re.S)
    if stripped.count("{") != stripped.count("}"):
        errors.append(f"brace:{path.relative_to(ROOT)}")

if errors:
    print("UNITY_ENGINEERING_STATIC_FAIL")
    print("\n".join(errors))
    sys.exit(1)

cs_count = len(list(ROOT.glob("Game/Assets/_Genesis/**/*.cs")))
print("UNITY_ENGINEERING_STATIC_PASS")
print(f"version={VERSION}")
print(f"cs_files={cs_count}")
print("pc_presentation_checks=10/10")
