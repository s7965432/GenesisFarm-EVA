# Verification — 0.1.4-vs

## Automated deterministic core
PASS: `node Prototype/verify.mjs`

Expected marker:
`GENESIS_VS_0_1_4_VERIFY_PASS`

Final run result:
- 35 named Vertical Slice nodes present
- 37 checks PASS (two repeated farm-operation checks are intentionally counted)
- Day 4 after restart
- Offline simulation 120 minutes
- 3 core memories including EVA birth, first harvest, first autonomous chicken feed
- AnimalCare XP 10
- grounded dialogue references the actual feeding EventID
- duplicate offline transaction guard PASS

## Static/runtime launch checks
- JS syntax: PASS for core.mjs, scenario.mjs, verify.mjs
- HTTP resource loading: tested before package release
- Browser visual rendering through Chromium: remains UNVERIFIED unless an actual successful headless/browser visual run is recorded

## Unity
UNVERIFIED: Unity Editor launch, Windows Player build, Android APK build/install. The package contains a Unity skeleton but this environment does not provide a validated Unity 6 execution path.
