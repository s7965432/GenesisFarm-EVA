# Changelog

## 0.1.4-vs
- Added explicit world/player/EVA lifecycle events and EVA birth core memory.
- Added a deterministic Vertical Slice Scenario Runner covering the full current acceptance chain.
- Added ordered PASS/FAIL node reporting with fail-fast behavior.
- Added AutosaveCompleted distinct from manual save.
- Added WorldStateRestored evidence after reload.
- Added restart + offline transaction idempotency regression coverage.
- Added in-prototype one-button Vertical Slice execution and report UI.
- Fixed runner navigation precision found by the first failed regression: adjacency stop could leave the player two Manhattan cells from the target plot.
- Fixed second demonstration positioning found by the next regression: the player had to move to the neighboring plot before tilling it.
