import {GameSim,MAP,VERSION} from './core.mjs';

export const VS_NODES=[
  'BOOT','CREATE_WORLD','CREATE_PLAYER','CREATE_EVA','ENTER_FARM','TILL_SOIL','PLANT_RADISH','PLAYER_DEMO_WATER_1','EVA_OBSERVE_1','PLAYER_DEMO_WATER_2','EVA_LEARN_WATER','EVA_AUTONOMOUS_WATER','CROP_MATURE','FIRST_SHARED_HARVEST','CORE_MEMORY','TRAVEL_TOWN','SHOP_TRANSACTION','GET_CHICKEN','CHICKEN_HUNGER','EVA_FEED_GOAL','EVA_PLAN_FEED','ACQUIRE_FEED','TRAVEL_COOP','FEED_CHICKEN','ANIMAL_STATE_CHANGED','EVA_EXPERIENCE_MEMORY','EVENING_REST','DIARY','AUTOSAVE','EXIT','OFFLINE_SIM','RESTART','WORLD_RESTORED','MEMORY_PERSISTED','GROUNDED_DIALOGUE'
];
const makeStorage=()=>{const m=new Map();return {setItem:(k,v)=>m.set(k,v),getItem:k=>m.get(k)??null,removeItem:k=>m.delete(k),_m:m};};
const has=(s,t,p=()=>true)=>s.events.some(e=>e.type===t&&p(e));
const near=(g,target,actor='player',stop=1)=>{let guard=200;while(g.dist(g.s[actor],target)>stop&&guard--){const a=g.s[actor];const dx=a.x<target.x?1:a.x>target.x?-1:0;const dy=dx===0?(a.y<target.y?1:a.y>target.y?-1:0):0;g.move(actor,dx,dy);}return guard>0;};
export function runVerticalSlice(storage=makeStorage()){
  const g=new GameSim();const report=[];const pass=(id,detail='')=>report.push({id,status:'PASS',detail});const check=(id,cond,detail='')=>{if(!cond){report.push({id,status:'FAIL',detail});const err=new Error(`VS_NODE_FAIL:${id}:${detail}`);err.report=report;throw err;}pass(id,detail);};
  check('BOOT',g.state().version===VERSION,VERSION);
  check('CREATE_WORLD',g.createWorld(),'WorldCreated');
  check('CREATE_PLAYER',g.s.lifecycle.playerCreated&&has(g.s,'PlayerCreated'));
  check('CREATE_EVA',g.s.lifecycle.evaCreated&&has(g.s,'EVACreated'));
  check('ENTER_FARM',g.s.lifecycle.enteredFarm&&has(g.s,'FarmEntered'));
  near(g,{x:7,y:5},'player',0);g.s.eva.x=7;g.s.eva.y=5;
  check('TILL_SOIL',g.playerTill(7,6));check('PLANT_RADISH',g.playerPlant(7,6));
  check('PLAYER_DEMO_WATER_1',g.playerWater(7,6));check('EVA_OBSERVE_1',has(g.s,'ObservationEvent')&&!g.s.eva.knowsWater);
  g.setPlayer(8,5);check('TILL_SOIL',g.playerTill(8,6),'second plot');check('PLANT_RADISH',g.playerPlant(8,6),'second plot');
  check('PLAYER_DEMO_WATER_2',g.playerWater(8,6));check('EVA_LEARN_WATER',g.s.eva.knowsWater&&has(g.s,'KnowledgeLearned'));
  g.advanceDay();let guard=80;while(guard--&&!has(g.s,'CropWatered',e=>e.detail.actor==='eva'))g.evaStep();check('EVA_AUTONOMOUS_WATER',has(g.s,'CropWatered',e=>e.detail.actor==='eva'));
  g.advanceDay();const ripe=g.s.plots.find(p=>p.ready);check('CROP_MATURE',!!ripe&&ripe.stage===3);
  g.setPlayer(ripe.x,ripe.y-1);g.s.eva.x=ripe.x;g.s.eva.y=ripe.y-1;check('FIRST_SHARED_HARVEST',g.harvest(ripe.x,ripe.y));const hm=g.s.eva.memories.find(m=>m.type==='FIRST_HARVEST');check('CORE_MEMORY',!!hm&&hm.core&&!!hm.eventId);
  g.setPlayer(MAP.townGate.x-1,MAP.townGate.y);g.move('player',1,0);check('TRAVEL_TOWN',has(g.s,'RegionEntered',e=>e.detail.actor==='player'&&e.detail.region==='Town'));near(g,MAP.shop);
  check('SHOP_TRANSACTION',g.buyChicken(),'buy chicken');check('GET_CHICKEN',g.s.chicken.owned);
  g.s.inventory.feed=0;g.s.chicken.hunger=.90;check('CHICKEN_HUNGER',g.s.chicken.hunger>=.6);
  g.s.eva.currentPlan=[];guard=180;while(guard--&&!has(g.s,'AnimalFed'))g.evaStep();check('EVA_FEED_GOAL',has(g.s,'EVAGoalSelected',e=>e.detail.goal==='feed'));const planEv=g.s.events.find(e=>e.type==='EVAPlanBuilt'&&e.detail.goal==='feed');check('EVA_PLAN_FEED',!!planEv&&planEv.detail.steps.join(',')==='move,buy_feed,move,feed',planEv?.detail.steps?.join('→'));
  check('ACQUIRE_FEED',has(g.s,'ShopTransaction',e=>e.detail.actor==='eva'&&e.detail.item==='feed'));check('TRAVEL_COOP',has(g.s,'RegionEntered',e=>e.detail.actor==='eva'&&e.detail.region==='Farm')&&g.dist(g.s.eva,MAP.coop)<=1);
  check('FEED_CHICKEN',has(g.s,'AnimalFed',e=>e.detail.actor==='eva'));check('ANIMAL_STATE_CHANGED',g.s.chicken.hunger<.2&&g.s.chicken.lastFedBy==='eva');const fm=g.s.eva.memories.find(m=>m.type==='FIRST_SELF_FEED_CHICKEN');check('EVA_EXPERIENCE_MEMORY',g.s.eva.skills.animalCare.xp>=10&&!!fm?.eventId);
  g.setPlayer(MAP.home.x,MAP.home.y);check('EVENING_REST',g.sleepPlayer());check('DIARY',g.s.eva.diary.length>0&&g.s.eva.diary.at(-1).eventIds.length>0);
  check('AUTOSAVE',g.autosave(storage)&&has(g.s,'AutosaveCompleted'));pass('EXIT','simulated process exit after persisted save');
  const savedDay=g.s.day;const txn='VS-OFFLINE-120';const r=new GameSim();check('OFFLINE_SIM',r.resume(storage,120,txn));check('RESTART',has(r.s,'ReloadCompleted')&&has(r.s,'WorldResumed'));check('WORLD_RESTORED',r.s.day===savedDay&&r.s.chicken.owned&&has(r.s,'WorldStateRestored'));
  check('MEMORY_PERSISTED',r.s.eva.memories.some(m=>m.type==='FIRST_HARVEST')&&r.s.eva.memories.some(m=>m.type==='FIRST_SELF_FEED_CHICKEN'));const speech=r.talkEVA('chicken');check('GROUNDED_DIALOGUE',speech.includes(fm.eventId)&&speech.includes('第一次自己買了飼料'),speech);
  const ids=report.map(x=>x.id);for(const id of VS_NODES)if(!ids.includes(id))throw new Error(`VS_NODE_NOT_REPORTED:${id}`);
  return {sim:r,storage,report,summary:{version:VERSION,passed:report.filter(x=>x.status==='PASS').length,total:report.length,day:r.s.day,offlineMinutes:r.s.offline.totalMinutes,coreMemories:r.s.eva.memories.filter(m=>m.core).length,animalCareXP:r.s.eva.skills.animalCare.xp,speech}};
}
