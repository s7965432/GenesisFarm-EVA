# 新生農場：EVA

Current development package: **0.1.4-vs**

This package turns the previous feature-by-feature validation harness into a deterministic **Vertical Slice Scenario Runner**. It starts from a clean world and verifies the complete playable logic chain in order: world/player/EVA creation, farm entry, till/plant/player watering demonstrations, EVA observation and learning, autonomous watering, crop maturity, first shared harvest and core memory, physical town travel, shop transaction, chicken acquisition and hunger, autonomous FeedChicken goal/plan/feed acquisition/return-to-coop feeding, AnimalCare experience and evidence-linked memory, evening rest, evidence-linked diary, autosave, simulated exit, offline settlement, restart/world restore, memory persistence, and event-grounded dialogue.

Open `Prototype/index.html` through a local HTTP server and press **從新世界跑完整 Vertical Slice** to see every validation node. Any failed node stops the run immediately.

Run `node Prototype/verify.mjs` for deterministic regression verification.

Unity project skeleton lives under `Game/` and remains **UNVERIFIED** until a real Unity 6 Editor/Player environment executes it.
