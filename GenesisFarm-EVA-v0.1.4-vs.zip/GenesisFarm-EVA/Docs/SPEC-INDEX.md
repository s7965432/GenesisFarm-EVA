# Specification Index

- GDD v1.0 — game vision, 3D third-person, HUD/UI, daily/long loops, MVP scope.
- AI-SPEC v1.0 — EVA needs, emotion, personality, skills, memory, goals, planning, autonomy.
- FARM-SPEC v1.0 — soil/crops/tools/animals/processing/economy/land.
- WORLD-SPEC v1.0 — regions, time, seasons, weather, town/NPC/events.
- BUILD-SPEC v1.0 — modular building, furniture, utilities, navigation rebuild.
- CHARACTER-SPEC v1.0 — player/EVA/NPC visual, animation, gaze, voice, interaction.
- CONTENT-DATA-SPEC v1.0 — persistent IDs, definitions, crops/items/animals/NPC/shop baseline.
- EVA-RUNTIME-SPEC v1.0 — authoritative EVAState, memory DB, utility/GOAP, AI JSON boundary.
- QA-RELEASE-SPEC v1.0 — severity, regression, long-run, save corruption, platform release gates.
- PRODUCTION-SPEC v1.0 — WBS, milestones, Vertical Slice→Alpha→Beta→RC→1.0.
- VS-IMPLEMENTATION-BLUEPRINT v1.0 — file/module responsibilities and implementation order.
