using System;
using System.Collections.Generic;
namespace Genesis.AI { [Serializable] public sealed class EVAState { public string EvaId="EVA_PRIMARY_001"; public float Hunger; public float Sleep; public float Social; public float Curiosity; public float Safety; public float WaterKnowledge; public bool KnowsWater; public float FarmingConfidence=.1f; public string CurrentGoal="Observe player"; public List<string> CoreMemoryIds=new(); } }
