using System;
using System.Collections.Generic;
namespace Genesis.Inventory { [Serializable] public sealed class InventoryState { public int Capacity=24; public Dictionary<string,int> Quantities=new(); } }
