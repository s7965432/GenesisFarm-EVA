using System;
namespace Genesis.Core {
[Serializable] public struct GameTime { public long TotalMinutes; public int Year => (int)(TotalMinutes / (112L*24*60))+1; public int DayOfYear => (int)(TotalMinutes/(24*60)%112)+1; public int SeasonIndex => (DayOfYear-1)/28; public int Day => (DayOfYear-1)%28+1; public int Hour => (int)(TotalMinutes/60%24); public int Minute => (int)(TotalMinutes%60); }
}
