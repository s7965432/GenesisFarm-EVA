using System;
namespace Genesis.Farm { [Serializable] public sealed class CropInstance { public string Id; public string DefinitionId; public string SoilCellId; public float Growth; public bool WateredToday; public bool ReadyToHarvest; } }
