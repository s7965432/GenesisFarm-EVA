using System;
namespace Genesis.Farm { [Serializable] public sealed class SoilCell { public string Id; public int X; public int Y; public bool Tilled; public float Moisture; public string CropInstanceId; } }
