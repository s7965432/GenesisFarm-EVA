# Genesis Farm: EVA — v0.1.6-vs

This package advances the verified Vertical Slice into the Unity PC runtime layer.

Current Unity runtime includes:
- programmatic farm/world bootstrap
- player movement and physical interaction
- EVA agent with explicit behavior states
- crop stage rendering and daily growth
- chicken ownership, hunger, feeding and eggs
- shared daily world processing for sleep and natural midnight rollover
- real-time clock + directional sun/ambient response
- JSON save/load with version restoration
- F8 Unity runtime verifier
- Windows x64 Editor build menu

Browser deterministic Scenario Runner remains the regression oracle until Unity Editor execution is available.
