using System.IO;
using Genesis.Core;
using UnityEngine;

namespace Genesis.Persistence
{
    public sealed class JsonSaveService
    {
        public string PathName => Path.Combine(Application.persistentDataPath, "genesis-vs-slot-1.json");
        public void Save(WorldRuntimeState state) => File.WriteAllText(PathName, JsonUtility.ToJson(state, true));
        public WorldRuntimeState Load()
        {
            if (!File.Exists(PathName)) return null;
            var state = JsonUtility.FromJson<WorldRuntimeState>(File.ReadAllText(PathName));
            if (state == null) return null;
            state.Version = GameBootstrap.Version;
            if (state.Eva != null && string.IsNullOrEmpty(state.Eva.BehaviorState)) state.Eva.BehaviorState = "Restored";
            state.AddEvent("SaveLoaded", GameBootstrap.Version);
            return state;
        }
    }
}
