using System;
using System.Linq;

namespace Genesis.Core
{
    public sealed class VerticalSliceRuntime
    {
        public const int Width = 24;
        public const int Height = 16;
        public WorldRuntimeState State { get; private set; }
        public event Action StateChanged;

        public VerticalSliceRuntime(WorldRuntimeState state = null)
        {
            State = state ?? WorldRuntimeState.CreateFresh();
        }

        public void ReplaceState(WorldRuntimeState state)
        {
            State = state ?? WorldRuntimeState.CreateFresh();
            StateChanged?.Invoke();
        }

        public PlotRuntimeState PlotAt(int x, int y) => State.Plots.FirstOrDefault(p => p.X == x && p.Y == y);
        public int Distance(int ax, int ay, int bx, int by) => Math.Abs(ax - bx) + Math.Abs(ay - by);

        public bool Till(int x, int y)
        {
            var p = PlotAt(x, y);
            if (p == null || Distance(State.Player.X, State.Player.Y, x, y) > 1) return false;
            p.Tilled = true;
            AdvanceMinutes(4);
            State.AddEvent("SoilTilled", p.Id);
            Changed();
            return true;
        }

        public bool Plant(int x, int y)
        {
            var p = PlotAt(x, y);
            if (p == null || !p.Tilled || p.Planted || State.Inventory.RadishSeed <= 0 || Distance(State.Player.X, State.Player.Y, x, y) > 1) return false;
            p.Planted = true; p.Stage = 1; p.Growth = 0; p.Ready = false;
            State.Inventory.RadishSeed--;
            AdvanceMinutes(3);
            State.AddEvent("CropPlanted", p.Id + ":radish");
            Changed();
            return true;
        }

        public bool Water(int x, int y, string actor)
        {
            var p = PlotAt(x, y);
            if (p == null || !p.Planted || p.Ready || p.Watered || State.Inventory.WateringCanWater <= 0) return false;
            if (actor == "player" && Distance(State.Player.X, State.Player.Y, x, y) > 1) return false;
            State.Inventory.WateringCanWater--;
            p.Watered = true;
            AdvanceMinutes(2);
            State.AddEvent("CropWatered", p.Id + ":" + actor);
            if (actor == "player" && Distance(State.Eva.X, State.Eva.Y, x, y) <= 4)
            {
                State.Eva.WaterKnowledge = Math.Min(1f, State.Eva.WaterKnowledge + .35f);
                State.AddEvent("ObservationEvent", "water_crop");
                if (!State.Eva.KnowsWater && State.Eva.WaterKnowledge >= .70f)
                {
                    State.Eva.KnowsWater = true;
                    State.Eva.Confidence = .35f;
                    State.AddEvent("KnowledgeLearned", "water_crop");
                }
            }
            if (actor == "eva") State.Eva.FarmingXp += 3;
            Changed();
            return true;
        }

        public bool Harvest(int x, int y)
        {
            var p = PlotAt(x, y);
            if (p == null || !p.Ready || Distance(State.Player.X, State.Player.Y, x, y) > 1) return false;
            p.Planted = false; p.Ready = false; p.Watered = false; p.Growth = 0; p.Stage = 0;
            State.Inventory.Radish++;
            AdvanceMinutes(4);
            var ev = State.AddEvent("CropHarvested", p.Id + ":radish");
            if (!State.Eva.Memories.Any(m => m.Type == "FIRST_HARVEST") && Distance(State.Eva.X, State.Eva.Y, x, y) <= 5)
                State.Eva.Memories.Add(new MemoryRuntimeState { Id = "MEM-FIRST-HARVEST", Type = "FIRST_HARVEST", EventId = ev.Id, Core = true, Day = State.Day, Summary = "我們第一次一起收成了白蘿蔔。" });
            Changed();
            return true;
        }

        public bool BuyChicken()
        {
            if (State.Chicken.Owned || State.Inventory.Coin < 250) return false;
            State.Inventory.Coin -= 250;
            State.Chicken.Owned = true;
            State.Chicken.Hunger = .35f;
            State.AddEvent("ShopTransaction", "player:buy:chicken:250");
            State.AddEvent("ChickenJoinedFarm", "MainCoop");
            Changed();
            return true;
        }


        public bool RefillPlayer()
        {
            if (Distance(State.Player.X, State.Player.Y, 2, 10) > 1) return false;
            State.Inventory.WateringCanWater = 20;
            AdvanceMinutes(3);
            State.AddEvent("WateringCanRefilled", "player:farm_well");
            Changed();
            return true;
        }

        public bool BuyFeed(string actor = "player")
        {
            const int price = 30;
            if (State.Inventory.Coin < price) return false;
            State.Inventory.Coin -= price;
            State.Inventory.Feed += 3;
            AdvanceMinutes(5);
            State.AddEvent("ShopTransaction", actor + ":buy:feed:3:30");
            Changed();
            return true;
        }

        public bool FeedChicken(string actor)
        {
            if (!State.Chicken.Owned || State.Inventory.Feed <= 0) return false;
            State.Inventory.Feed--;
            State.Chicken.Hunger = .12f;
            State.Chicken.FedCount++;
            State.Chicken.LastFedBy = actor;
            if (actor == "eva") State.Eva.AnimalCareXp += 10;
            var ev = State.AddEvent("AnimalFed", actor + ":chicken");
            if (actor == "eva" && !State.Eva.Memories.Any(m => m.Type == "FIRST_SELF_FEED_CHICKEN"))
                State.Eva.Memories.Add(new MemoryRuntimeState { Id = "MEM-FIRST-SELF-FEED-CHICKEN", Type = "FIRST_SELF_FEED_CHICKEN", EventId = ev.Id, Core = true, Day = State.Day, Summary = "我第一次自己買了飼料，走回雞舍把雞餵飽了。" });
            Changed();
            return true;
        }

        public bool SleepPlayer()
        {
            if (Distance(State.Player.X, State.Player.Y, 3, 3) > 2) return false;
            State.AddEvent("PlayerSlept", State.Day.ToString());
            AdvanceDay();
            State.Player.Energy = 100f;
            return true;
        }

        public void AdvanceDay()
        {
            ProcessNewDay();
            State.Minute = 6 * 60;
            Changed();
        }

        public void AdvanceMinutes(int minutes)
        {
            State.Minute += minutes;
            while (State.Minute >= 1440)
            {
                State.Minute -= 1440;
                ProcessNewDay();
            }
            Changed();
        }

        private void ProcessNewDay()
        {
            State.Day++;
            State.Weather = State.Day % 3 == 0 ? "Rain" : "Clear";
            foreach (var p in State.Plots.Where(p => p.Planted))
            {
                if (p.Watered || State.Weather == "Rain") p.Growth = Math.Min(1f, p.Growth + .5f);
                p.Stage = p.Growth >= 1f ? 3 : p.Growth >= .5f ? 2 : 1;
                p.Ready = p.Growth >= 1f;
                p.Watered = State.Weather == "Rain";
            }
            if (State.Chicken.Owned)
            {
                State.Chicken.Hunger = Math.Min(1f, State.Chicken.Hunger + .38f);
                if (State.Chicken.Hunger < .6f) State.Chicken.Eggs++;
            }
            State.AddEvent("GameDayAdvanced", State.Day + ":" + State.Weather);
        }

        public string TalkAboutRecentMemory()
        {
            var memory = State.Eva.Memories.LastOrDefault();
            return memory == null ? "我還沒有能確認的相關記憶。" : $"我記得。{memory.Summary}（記憶來源 {memory.EventId}）";
        }

        private void Changed() => StateChanged?.Invoke();
    }
}
