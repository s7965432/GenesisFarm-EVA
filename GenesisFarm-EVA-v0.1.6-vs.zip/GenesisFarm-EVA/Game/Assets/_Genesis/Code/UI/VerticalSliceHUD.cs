using Genesis.Core;
using Genesis.Interaction;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.UI
{
    public sealed class VerticalSliceHUD : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public PlayerInteractor Interactor { get; set; }
        public string Message = "E 互動｜1鋤頭 2種子 3澆水 4收成｜F5存檔 F9讀檔";
        public System.Action SaveRequested;
        public System.Action LoadRequested;
        public UnityVerticalSliceVerifier Verifier { get; set; }

        private void Update()
        {
            var k = Keyboard.current;
            if (k == null) return;
            if (k.f5Key.wasPressedThisFrame) SaveRequested?.Invoke();
            if (k.f9Key.wasPressedThisFrame) LoadRequested?.Invoke();
            if (k.tKey.wasPressedThisFrame) Message = Runtime.TalkAboutRecentMemory();
        }

        private void OnGUI()
        {
            if (Runtime == null) return;
            var s = Runtime.State;
            GUI.Box(new Rect(12, 12, 470, 166), "Genesis Farm: EVA  " + GameBootstrap.Version);
            GUI.Label(new Rect(24, 38, 400, 22), $"Day {s.Day}  {s.Minute/60:00}:{s.Minute%60:00}  Weather: {s.Weather}");
            GUI.Label(new Rect(24, 60, 400, 22), $"Coin {s.Inventory.Coin}  Seeds {s.Inventory.RadishSeed}  Radish {s.Inventory.Radish}  Feed {s.Inventory.Feed}");
            GUI.Label(new Rect(24, 82, 440, 22), $"EVA Goal: {s.Eva.CurrentGoal}  State: {s.Eva.BehaviorState}");
            GUI.Label(new Rect(24, 104, 440, 22), $"Knowledge {s.Eva.WaterKnowledge:0.00}  AnimalCare XP {s.Eva.AnimalCareXp}  Energy {s.Eva.Energy:0}");
            GUI.Label(new Rect(24, 126, 440, 22), $"Tool: {Interactor?.SelectedTool ?? "-"}  Chicken: {(s.Chicken.Owned ? $"Hunger {s.Chicken.Hunger:0.00} Eggs {s.Chicken.Eggs}" : "not owned")}");
            var interaction = Interactor != null && !string.IsNullOrEmpty(Interactor.LastMessage) ? Interactor.LastMessage : Message;
            GUI.Label(new Rect(24, 148, 440, 22), interaction);
            if (Verifier != null) GUI.Label(new Rect(12, 184, 700, 22), Verifier.LastReport);
        }
    }
}
