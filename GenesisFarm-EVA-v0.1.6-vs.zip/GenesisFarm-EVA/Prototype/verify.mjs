import {runVerticalSlice,VS_NODES} from './scenario.mjs';
const result=runVerticalSlice();
if(result.report.some(x=>x.status!=='PASS'))throw new Error('scenario has failed nodes');
for(const id of VS_NODES){if(!result.report.some(x=>x.id===id&&x.status==='PASS'))throw new Error(`missing pass: ${id}`)}
// Transaction idempotency after restart must remain protected.
const before=result.sim.state().offline.totalMinutes;
result.sim.offline(120,'VS-OFFLINE-120');
if(result.sim.state().offline.totalMinutes!==before)throw new Error('duplicate offline settlement applied');
console.log('GENESIS_VS_0_1_6_VERIFY_PASS');
console.log(JSON.stringify({...result.summary,nodes:VS_NODES.length,duplicateOfflineGuard:true},null,2));
