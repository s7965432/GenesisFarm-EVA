# Changelog

## 0.1.1-vs — 2026-09-07

- Replaced the button-only harness with a navigable HTML5 canvas farm scene.
- Added keyboard and mobile on-screen movement controls.
- Added physical map locations for home, farm, well, shop and chicken coop.
- Added 12 persistent farm plots with till / plant / water / growth / harvest state.
- EVA now needs two valid nearby watering observations (0.35 evidence each) before learning.
- EVA moves toward dry crops before performing autonomous watering.
- Added shop chicken purchase with 250-coin debit.
- EVA moves to the coop and autonomously feeds a hungry chicken.
- Added evidence-linked daily diary entries.
- Preserved core memory, save/reload and idempotent offline transaction verification.
- Added Unity-side data skeleton classes: GameTime, Result, SoilCell, CropInstance, EVAState, InventoryState.
- Fixed observation test geometry found by automated verification.
