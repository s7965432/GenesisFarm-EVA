# GenesisFarm-EVA / 新生農場：EVA

Version: **0.1.1-vs**

This package advances the Vertical Slice from a button-only runtime harness to an actually navigable first farm scene.

## Playable prototype

Open through a local HTTP server (ES modules are used):

```bash
cd Prototype
python -m http.server 8000
```

Then open `http://localhost:8000`.

Controls: WASD / arrow keys, plus on-screen mobile direction buttons.

Current playable loop:
- walk around the farm map
- till and plant radish plots
- player demonstrates watering twice near EVA
- observation evidence unlocks EVA watering knowledge
- EVA physically moves toward dry crops and waters them
- crop growth / mature / harvest
- first harvest creates a core memory linked to a real event
- walk to the shop and buy a chicken
- EVA physically moves to the coop and feeds a hungry chicken
- evidence-linked daily diary
- save / reload
- idempotent 120-minute offline simulation

Automated verification:

```bash
node Prototype/verify.mjs
```
