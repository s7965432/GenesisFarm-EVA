# Vertical Slice Verification Report

Version: 0.1.1-vs
Date: 2026-09-07

## Runtime simulation

Command: `node Prototype/verify.mjs`

Expected pass marker: `GENESIS_VS_0_1_1_VERIFY_PASS`

Verifies:
- map/player runtime boot
- player movement
- till / plant / water
- EVA requires two observed watering demonstrations
- knowledge evidence threshold unlocks watering
- EVA moves toward a dry crop and waters autonomously
- crop maturation and harvest
- first harvest creates event-linked core memory
- shop chicken purchase atomically debits 250 coin
- EVA moves toward coop and feeds hungry chicken
- daily diary contains real event IDs
- save/reload preserves EVA memory
- duplicate offline transaction is blocked

## Browser prototype

Uses an HTML5 canvas farm map with player, EVA, farm plots, well, shop, house and coop. Keyboard and on-screen movement controls are provided.

## Unity

Unity project remains a project skeleton. Unity Editor is not installed in the current execution environment, so Unity Editor/Windows/Android player builds remain **UNVERIFIED** and are not claimed as PASS.

## Actual execution result

`node Prototype/verify.mjs` result: **PASS**

Observed final state:
- version: 0.1.1-vs
- day: 4
- EVA watering knowledge: 0.70
- EVA knows watering: true
- core memories: 1
- chicken owned: true
- chicken fed count: 1
- diary entries: 3
- offline committed minutes: 120

HTTP boot test (`index.html`, `core.mjs`, `game.js`): **PASS**
