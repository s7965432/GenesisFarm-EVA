import {GameSim,MAP,VERSION} from './core.mjs';
const ok=(v,m)=>{if(!v)throw new Error(m)};const store=new Map(),storage={setItem:(k,v)=>store.set(k,v),getItem:k=>store.get(k)??null};
const g=new GameSim();ok(g.state().version===VERSION,'version mismatch');
// player reaches field edge and prepares two plots
for(let i=0;i<4;i++){g.move('player',1,0);g.evaStep()}for(let i=0;i<2;i++){g.move('player',0,1);g.evaStep()}
ok(g.playerTill(7,6),'till plot1');ok(g.playerPlant(7,6),'plant plot1');ok(g.playerWater(7,6),'water plot1');
ok(!g.state().eva.knowsWater,'EVA learned too early');
g.playerTill(8,6);g.playerPlant(8,6);ok(g.playerWater(8,6),'water plot2');ok(g.state().eva.knowsWater,'EVA did not learn after two observations');
// day 2 dries both, EVA must autonomously water at least one after moving
 g.advanceDay(); let guard=20,action='';while(guard--&&action!=='water_crop')action=g.evaStep();ok(action==='water_crop','EVA failed autonomous watering');
// mature and harvest one crop, create core memory
 g.advanceDay();const ripe=g.state().plots.find(p=>p.ready);ok(ripe,'no ripe crop');g.setPlayer(ripe.x,ripe.y-1);g.s.eva.x=ripe.x;g.s.eva.y=ripe.y-1;ok(g.harvest(ripe.x,ripe.y),'harvest failed');ok(g.state().eva.memories.some(m=>m.core),'core memory missing');
// buy chicken
 g.setPlayer(MAP.shop.x-1,MAP.shop.y);ok(g.buyChicken(),'buy chicken failed');ok(g.state().inventory.coin===250,'coin transaction wrong');
// force hunger by day advance, EVA goes to coop and feeds
 g.s.chicken.hunger=.9;guard=30;action='';while(guard--&&action!=='feed_chicken')action=g.evaStep();ok(action==='feed_chicken','EVA failed chicken care');ok(g.state().chicken.fedCount===1,'feed count wrong');
// reflection based on real events
 g.advanceDay();ok(g.state().eva.diary.length>0,'diary missing');ok(g.state().eva.diary.some(d=>d.eventIds.length>0),'diary not evidence linked');
// persistence and offline idempotence
 g.save(storage);const memCount=g.state().eva.memories.length;const r=new GameSim();ok(r.load(storage),'reload failed');ok(r.state().eva.memories.length===memCount,'memory lost');ok(r.offline(120,'TXN-A'),'offline first failed');const one=r.state().offline.totalMinutes;ok(!r.offline(120,'TXN-A'),'duplicate offline not blocked');ok(r.state().offline.totalMinutes===one,'duplicate offline applied');
console.log('GENESIS_VS_0_1_1_VERIFY_PASS');console.log(JSON.stringify({version:VERSION,day:r.state().day,knowsWater:r.state().eva.knowsWater,waterKnowledge:r.state().eva.knowledgeWater,coreMemories:r.state().eva.memories.filter(m=>m.core).length,chickenOwned:r.state().chicken.owned,chickenFed:r.state().chicken.fedCount,diaryEntries:r.state().eva.diary.length,offlineMinutes:r.state().offline.totalMinutes},null,2));
