import {GameSim,MAP,VERSION} from './core.mjs';
const KEY='genesis-farm-eva-vs';
const sim=new GameSim();
const canvas=document.querySelector('#world'),ctx=canvas.getContext('2d');
const CELL=32; canvas.width=MAP.w*CELL;canvas.height=MAP.h*CELL;
const $=s=>document.querySelector(s);
let selectedPlot=null;
function tile(x,y,fill,label){ctx.fillStyle=fill;ctx.fillRect(x*CELL,y*CELL,CELL,CELL);ctx.strokeStyle='#0002';ctx.strokeRect(x*CELL,y*CELL,CELL,CELL);if(label){ctx.fillStyle='#203020';ctx.font='11px system-ui';ctx.fillText(label,x*CELL+3,y*CELL+18)}}
function render(){const s=sim.state();ctx.clearRect(0,0,canvas.width,canvas.height);for(let y=0;y<MAP.h;y++)for(let x=0;x<MAP.w;x++)tile(x,y,'#98bf6b');
for(const p of s.plots){let c=p.tilled?'#8b5a3c':'#789c51';if(p.watered)c='#6d6546';tile(p.x,p.y,c,p.crop?(p.ready?'🥕':'🌱'):'');}
tile(MAP.water.x,MAP.water.y,'#6ab7d6','井');tile(MAP.shop.x,MAP.shop.y,'#d7bb7a','店');tile(MAP.coop.x,MAP.coop.y,'#d29d68','雞舍');tile(MAP.home.x,MAP.home.y,'#c9c0a5','家');
ctx.font='24px system-ui';ctx.fillText('🙂',s.player.x*CELL+4,s.player.y*CELL+25);ctx.fillText('🤖',s.eva.x*CELL+4,s.eva.y*CELL+25);if(s.chicken.owned)ctx.fillText('🐔',MAP.coop.x*CELL+4,MAP.coop.y*CELL+25);
$('#status').textContent=`Day ${s.day} · ${s.weather} · ${String(Math.floor(s.minute/60)).padStart(2,'0')}:${String(s.minute%60).padStart(2,'0')} · ${VERSION}`;
$('#inventory').textContent=`💰 ${s.inventory.coin}　種子 ${s.inventory.radishSeed}　蘿蔔 ${s.inventory.radish}　飼料 ${s.inventory.feed}　水 ${s.inventory.wateringCanWater}/20`;
$('#eva').textContent=`EVA：${s.eva.currentGoal}｜澆水知識 ${(s.eva.knowledgeWater*100).toFixed(0)}%｜信心 ${(s.eva.confidence*100).toFixed(0)}%｜核心記憶 ${s.eva.memories.filter(m=>m.core).length}`;
$('#chicken').textContent=s.chicken.owned?`雞：飢餓 ${(s.chicken.hunger*100).toFixed(0)}%｜已餵 ${s.chicken.fedCount} 次｜蛋 ${s.chicken.eggs}`:'雞：尚未購入（走到商店旁按「買雞」）';
$('#diary').textContent=s.eva.diary.at(-1)?.text||'EVA 還沒有寫日記。';
$('#log').textContent=s.events.slice(-10).reverse().map(e=>`${e.id} D${e.day} ${e.type}`).join('\n');}
function nearPlot(){const s=sim.state();return sim.nearestPlot(p=>Math.abs(p.x-s.player.x)+Math.abs(p.y-s.player.y)<=1,s.player)}
function act(kind){const p=nearPlot();if(kind==='till'&&p)sim.playerTill(p.x,p.y);if(kind==='plant'&&p)sim.playerPlant(p.x,p.y);if(kind==='water'&&p)sim.playerWater(p.x,p.y);if(kind==='harvest'&&p)sim.harvest(p.x,p.y);if(kind==='refill')sim.refill();render()}
function move(dx,dy){sim.move('player',dx,dy);sim.evaStep();render()}
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k==='w'||e.key==='ArrowUp')move(0,-1);if(k==='s'||e.key==='ArrowDown')move(0,1);if(k==='a'||e.key==='ArrowLeft')move(-1,0);if(k==='d'||e.key==='ArrowRight')move(1,0)});
[['up',0,-1],['down',0,1],['left',-1,0],['right',1,0]].forEach(([id,x,y])=>$('#'+id).onclick=()=>move(x,y));
['till','plant','water','harvest','refill'].forEach(id=>$('#'+id).onclick=()=>act(id));
$('#evaStep').onclick=()=>{sim.evaStep();render()};$('#advance').onclick=()=>{sim.advanceDay();render()};$('#buyChicken').onclick=()=>{sim.buyChicken();render()};$('#save').onclick=()=>{sim.save(localStorage,KEY);render()};$('#reload').onclick=()=>{sim.load(localStorage,KEY);render()};$('#offline').onclick=()=>{sim.offline(120);render()};$('#reset').onclick=()=>{localStorage.removeItem(KEY);location.reload()};
render();window.__GENESIS_TEST__=sim;
