# Changelog

## 0.1.5-vs
- Began PC/Unity playable engineering phase from the verified 0.1.4 Vertical Slice baseline.
- Added Unity `WorldRuntimeState` and `VerticalSliceRuntime` authoritative runtime data/interaction layer.
- Added runtime-generated farm scene: ground, home, well, coop, town/shop marker and 12 farm plots.
- Added third-person player capsule, WASD/Input System movement, interaction ray and four tool modes.
- Added visible crop stage state and watered soil state.
- Added EVA scene actor with first autonomous follow/water/feed behavior bridge.
- Added chicken scene representation and hunger display behavior.
- Added JSON save/load to `Application.persistentDataPath` with F5/F9 HUD controls.
- Added runtime HUD for day/time/inventory/EVA/chicken state.
- Added Unity Editor scene builder (`Genesis > Build Vertical Slice Scene`) and automatic Build Settings registration.
- Browser deterministic scenario/version advanced to 0.1.5-vs for regression continuity.

## 0.1.4-vs
- Added full Vertical Slice Scenario Runner and complete deterministic acceptance chain.
- Added `Genesis.Runtime.asmdef` and Editor-only `Genesis.Editor.asmdef` to make assembly boundaries explicit.
- Added `Genesis > Build Windows x64` Editor build command targeting `Build/Windows/GenesisFarm-EVA.exe`.
