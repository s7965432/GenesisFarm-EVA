# Verification — 0.1.5-vs

## Deterministic logic gate
Run from `Prototype/`:

```bash
node verify.mjs
```

Expected: `GENESIS_VS_0_1_5_VERIFY_PASS` and every Vertical Slice node PASS.

## Unity engineering checks
The package now contains a runtime-generated playable scene layer and an Editor scene builder. The execution environment used to package this release does **not** contain Unity Editor, therefore the following remain explicitly UNVERIFIED here:
- Unity C# compilation against the exact installed Unity 6 LTS revision.
- Editor scene generation execution.
- Windows x64 Player build/launch.
- Android ARM64 build/launch.

Static package checks validate expected scripts, namespaces, version consistency, braces, required Input System package declaration, and no stale 0.1.4 version token in executable prototype/runtime sources.

## Assembly/build tooling
- `Genesis.Runtime.asmdef` isolates gameplay runtime and explicitly references `Unity.InputSystem`.
- `Genesis.Editor.asmdef` is Editor-only and references `Genesis.Runtime`.
- `Genesis > Build Windows x64` builds the generated Vertical Slice scene to `Build/Windows/GenesisFarm-EVA.exe` when executed inside Unity.
