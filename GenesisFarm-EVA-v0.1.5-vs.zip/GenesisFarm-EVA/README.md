# Genesis Farm: EVA — v0.1.5-vs

Vertical Slice logic remains deterministically verified in `Prototype/`, while `Game/` now contains the first Unity-playable engineering layer.

## Unity first-run
1. Open `Game/` with the Unity 6 LTS baseline.
2. Run menu `Genesis > Build Vertical Slice Scene`.
3. Open/play `Assets/_Genesis/Scenes/VerticalSlice.unity`.
4. WASD / arrows move. `1` hoe, `2` seed, `3` water, `4` harvest, `E` interact. `F5` save, `F9` load.

The runtime bootstrap programmatically creates the farm, player, EVA, plots, well, coop, town/shop marker, camera, chicken and HUD. No prefab setup is required for this engineering slice.

## Windows x64 build
After the scene has been generated, run `Genesis > Build Windows x64`. The Editor build script targets `StandaloneWindows64` and writes `Build/Windows/GenesisFarm-EVA.exe`.
