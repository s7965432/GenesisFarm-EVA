using UnityEngine;

namespace Genesis.Core
{
    public sealed class GameBootstrap : MonoBehaviour
    {
        public const string Version = "0.1.5-vs";

        private void Awake()
        {
            Debug.Log($"Genesis Farm EVA boot {Version}");
        }
    }
}
