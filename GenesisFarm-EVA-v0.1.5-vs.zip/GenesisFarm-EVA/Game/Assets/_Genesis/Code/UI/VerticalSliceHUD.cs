using Genesis.Core;
using Genesis.Interaction;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Genesis.UI
{
    public sealed class VerticalSliceHUD : MonoBehaviour
    {
        public VerticalSliceRuntime Runtime { get; set; }
        public PlayerInteractor Interactor { get; set; }
        public string Message = "E 互動｜1鋤頭 2種子 3澆水 4收成｜F5存檔 F9讀檔";
        public System.Action SaveRequested;
        public System.Action LoadRequested;

        private void Update()
        {
            var k = Keyboard.current;
            if (k == null) return;
            if (k.f5Key.wasPressedThisFrame) SaveRequested?.Invoke();
            if (k.f9Key.wasPressedThisFrame) LoadRequested?.Invoke();
            if (k.tKey.wasPressedThisFrame) Message = Runtime.TalkAboutRecentMemory();
        }

        private void OnGUI()
        {
            if (Runtime == null) return;
            var s = Runtime.State;
            GUI.Box(new Rect(12, 12, 430, 142), "Genesis Farm: EVA  " + GameBootstrap.Version);
            GUI.Label(new Rect(24, 38, 400, 22), $"Day {s.Day}  {s.Minute/60:00}:{s.Minute%60:00}  Weather: {s.Weather}");
            GUI.Label(new Rect(24, 60, 400, 22), $"Coin {s.Inventory.Coin}  Seeds {s.Inventory.RadishSeed}  Radish {s.Inventory.Radish}  Feed {s.Inventory.Feed}");
            GUI.Label(new Rect(24, 82, 400, 22), $"EVA Goal: {s.Eva.CurrentGoal}  Water knowledge: {s.Eva.WaterKnowledge:0.00}  AnimalCare XP: {s.Eva.AnimalCareXp}");
            GUI.Label(new Rect(24, 104, 400, 22), $"Tool: {Interactor?.SelectedTool ?? "-"}  Chicken: {(s.Chicken.Owned ? $"Hunger {s.Chicken.Hunger:0.00}" : "not owned")}");
            var interaction = Interactor != null && !string.IsNullOrEmpty(Interactor.LastMessage) ? Interactor.LastMessage : Message;
            GUI.Label(new Rect(24, 126, 400, 22), interaction);
        }
    }
}
