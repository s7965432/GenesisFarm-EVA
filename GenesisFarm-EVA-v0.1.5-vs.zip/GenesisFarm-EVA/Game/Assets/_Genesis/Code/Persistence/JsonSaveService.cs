using System.IO;
using Genesis.Core;
using UnityEngine;

namespace Genesis.Persistence
{
    public sealed class JsonSaveService
    {
        public string PathName => Path.Combine(Application.persistentDataPath, "genesis-vs-slot-1.json");
        public void Save(WorldRuntimeState state) => File.WriteAllText(PathName, JsonUtility.ToJson(state, true));
        public WorldRuntimeState Load()
        {
            if (!File.Exists(PathName)) return null;
            var state = JsonUtility.FromJson<WorldRuntimeState>(File.ReadAllText(PathName));
            return state;
        }
    }
}
