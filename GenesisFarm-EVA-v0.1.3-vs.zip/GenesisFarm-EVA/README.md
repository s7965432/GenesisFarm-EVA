# 新生農場：EVA

Current development package: **0.1.3-vs**

This Vertical Slice runtime harness now verifies the farm learning loop plus physical town travel, shop transactions, chicken hunger, EVA FeedChicken utility goal, feed acquisition, return-to-coop feeding, AnimalCare experience, evidence-linked memory/diary, save/offline/restart persistence, and memory-grounded dialogue.

Open `Prototype/index.html` through a local HTTP server for the interactive validation prototype.
Run `node Prototype/verify.mjs` for deterministic core regression verification.

Unity project skeleton lives under `Game/` and remains intentionally **UNVERIFIED** until tested with a real Unity 6 environment.
