# Changelog

## 0.1.3-vs
- Added explicit Farm/Town regions and RegionEntered events.
- Added physical shop travel for player and EVA.
- Added feed shop transaction and EVA spend-limit validation.
- FeedChicken plan now acquires missing feed, returns to coop, and feeds the chicken.
- Added chicken hunger result, last feeder, and AnimalCare XP.
- Added FIRST_SELF_FEED_CHICKEN core memory linked to AnimalFed EventID.
- Added evidence-linked chicken diary entry.
- Added EVA dialogue grounded in stored memory EventID.
- Added save -> offline -> restart `resume()` transaction with duplicate-settlement guard persisted immediately.
