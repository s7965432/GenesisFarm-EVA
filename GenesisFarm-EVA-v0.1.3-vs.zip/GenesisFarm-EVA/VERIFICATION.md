# Verification — GenesisFarm-EVA 0.1.3-vs

## PASS
- Deterministic core regression: `GENESIS_VS_0_1_3_VERIFY_PASS`
- Player Farm -> Town region transition event.
- Player shop transaction for chicken.
- Chicken hunger triggers EVA `feed` Utility Goal.
- Empty-feed case builds `move -> buy_feed -> move -> feed` plan.
- EVA physically enters Town, buys feed, returns to coop, and feeds chicken.
- Chicken hunger changes after feed.
- AnimalCare XP increments by 10.
- FIRST_SELF_FEED_CHICKEN core memory links to the real `AnimalFed` EventID.
- Save -> offline -> restart/resume preserves chicken, EVA memory, and world state.
- Duplicate offline transaction is not applied twice after restart.
- EVA dialogue about feeding is grounded in the stored memory and cites its source EventID.
- Node syntax checks for `core.mjs`, `game.js`, and `verify.mjs`.
- HTTP resource boot: `index.html`, `game.js`, `core.mjs`, `style.css` all returned HTTP 200.
- DOM reference consistency check passed.

## Latest deterministic result
```json
{
  "version": "0.1.3-vs",
  "day": 3,
  "playerRegion": "Town",
  "chickenHunger": 0.22,
  "feedBoughtByEVA": 1,
  "animalCareXP": 10,
  "feedMemoryEvent": "EVT-69",
  "offlineMinutes": 120,
  "evaSpeech": "我記得。我第一次自己買了飼料，走回雞舍把雞餵飽了。（記憶來源 EVT-69）"
}
```

## UNVERIFIED
- Headless Chromium rendered DOM boot (process did not provide reliable DOM output in this environment).
- Unity Editor scene boot.
- Windows Unity Player build/run.
- Android APK build/install/run.
