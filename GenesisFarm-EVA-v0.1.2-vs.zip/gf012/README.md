# 新生農場：EVA

Current development package: **0.1.2-vs**

Open `Prototype/index.html` through a local HTTP server for the interactive validation prototype.
Run `node Prototype/verify.mjs` for deterministic core regression verification.

Unity project skeleton lives under `Game/` and is intentionally marked UNVERIFIED until tested with a real Unity 6 environment.
