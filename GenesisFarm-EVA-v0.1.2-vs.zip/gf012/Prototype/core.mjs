export const VERSION='0.1.2-vs';
export const MAP={w:24,h:16,farm:[7,6,10,8],water:{x:2,y:10},shop:{x:20,y:4},coop:{x:15,y:5},feedBin:{x:14,y:5},home:{x:3,y:3},bed:{x:3,y:2}};
const clone=o=>JSON.parse(JSON.stringify(o));
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export function freshState(){
  const plots=[]; for(let y=6;y<=8;y++)for(let x=7;x<=10;x++)plots.push({id:`PLOT_${x}_${y}`,x,y,tilled:false,crop:null,watered:false,growth:0,stage:0,ready:false});
  return {version:VERSION,day:1,minute:8*60,weather:'Clear',phase:'Morning',player:{x:3,y:4,energy:100,selected:'hoe'},eva:{x:5,y:4,energy:92,hunger:.15,sleepiness:.10,knowledgeWater:0,knowsWater:false,confidence:.10,currentGoal:'Observe player',currentPlan:[],currentAction:null,lastUtility:{},memories:[],actions:[],diary:[]},inventory:{radishSeed:8,radish:0,feed:3,coin:500,wateringCanWater:20},plots,chicken:{owned:false,hunger:0,fedCount:0,eggs:0},save:{lastSavedDay:null,lastSavedMinute:null,slot:'slot-1'},offline:{lastTxn:null,totalMinutes:0},events:[]};
}
export class GameSim{
  constructor(state=freshState()){this.s=clone(state);this._seq=this.s.events.length;}
  state(){return clone(this.s)}
  event(type,detail={}){const e={id:`EVT-${++this._seq}`,day:this.s.day,minute:this.s.minute,type,detail};this.s.events.push(e);return e;}
  dist(a,b){return Math.abs(a.x-b.x)+Math.abs(a.y-b.y)}
  _updatePhase(){const h=this.s.minute/60;this.s.phase=h<12?'Morning':h<17?'Afternoon':h<20?'Evening':'Night';}
  tick(minutes=1){this.s.minute+=minutes;while(this.s.minute>=24*60){this.s.minute-=24*60;this.advanceDay(true)}this._updatePhase();this.s.eva.hunger=clamp(this.s.eva.hunger+minutes/1440*.45);this.s.eva.sleepiness=clamp(this.s.eva.sleepiness+minutes/1440*.50);this.s.eva.energy=Math.max(0,this.s.eva.energy-minutes/120);}
  move(actor,dx,dy){const a=this.s[actor]; if(!a)return false; const nx=Math.max(0,Math.min(MAP.w-1,a.x+dx)), ny=Math.max(0,Math.min(MAP.h-1,a.y+dy)); a.x=nx;a.y=ny; this.tick(2); this.event(actor==='player'?'PlayerMoved':'EVAMoved',{x:nx,y:ny}); return true;}
  setPlayer(x,y){this.s.player.x=x;this.s.player.y=y}
  plotAt(x,y){return this.s.plots.find(p=>p.x===x&&p.y===y)||null}
  nearestPlot(filter=()=>true,from=this.s.eva){return this.s.plots.filter(filter).sort((a,b)=>this.dist(from,a)-this.dist(from,b))[0]||null}
  playerTill(x,y){const p=this.plotAt(x,y);if(!p||this.dist(this.s.player,p)>1)return false;p.tilled=true;this.tick(4);this.event('SoilTilled',{plot:p.id,actor:'player'});return true}
  playerPlant(x,y){const p=this.plotAt(x,y);if(!p||!p.tilled||p.crop||this.s.inventory.radishSeed<=0||this.dist(this.s.player,p)>1)return false;this.s.inventory.radishSeed--;p.crop='radish';p.growth=0;p.stage=1;p.ready=false;this.tick(3);this.event('CropPlanted',{plot:p.id,crop:'radish',actor:'player'});return true}
  _observeWater(p){if(this.dist(this.s.eva,p)>4)return;this.s.eva.knowledgeWater=Math.min(1,this.s.eva.knowledgeWater+.35);this.event('ObservationEvent',{observer:'eva',action:'water_crop',plot:p.id,evidence:.35});if(!this.s.eva.knowsWater&&this.s.eva.knowledgeWater>=.70){this.s.eva.knowsWater=true;this.s.eva.confidence=.35;this.event('KnowledgeLearned',{action:'water_crop',confidence:this.s.eva.knowledgeWater});}}
  _waterPlot(p,actor){if(!p||!p.crop||p.ready||p.watered)return false;if(this.s.inventory.wateringCanWater<=0)return false;this.s.inventory.wateringCanWater--;p.watered=true;this.tick(2);this.event('CropWatered',{plot:p.id,crop:p.crop,actor});if(actor==='player')this._observeWater(p);if(actor==='eva'){this.s.eva.actions.push('water_crop');this.s.eva.confidence=Math.min(1,this.s.eva.confidence+.08)}return true}
  playerWater(x,y){const p=this.plotAt(x,y);if(!p||this.dist(this.s.player,p)>1)return false;return this._waterPlot(p,'player')}
  refill(){if(this.dist(this.s.player,MAP.water)>1)return false;this.s.inventory.wateringCanWater=20;this.tick(3);this.event('WateringCanRefilled',{actor:'player'});return true}
  harvest(x,y,actor='player'){const p=this.plotAt(x,y);if(!p||!p.ready||this.dist(this.s[actor],p)>1)return false;p.crop=null;p.ready=false;p.watered=false;p.growth=0;p.stage=0;if(actor==='player')this.s.inventory.radish++;this.tick(4);const h=this.event('CropHarvested',{plot:p.id,crop:'radish',actor});if(!this.s.eva.memories.some(m=>m.type==='FIRST_HARVEST')&&this.dist(this.s.eva,p)<=5){this.s.eva.memories.push({id:'MEM-FIRST-HARVEST',type:'FIRST_HARVEST',eventId:h.id,core:true,day:this.s.day,summary:'我們第一次一起收成了白蘿蔔。'});this.event('MemoryCreated',{memory:'FIRST_HARVEST',eventId:h.id,core:true});}return true}
  buyChicken(){if(this.dist(this.s.player,MAP.shop)>1||this.s.chicken.owned||this.s.inventory.coin<250)return false;this.s.inventory.coin-=250;this.s.chicken.owned=true;this.s.chicken.hunger=.35;this.tick(10);this.event('ShopTransaction',{kind:'buy',item:'chicken',price:250});this.event('ChickenJoinedFarm',{coop:'MainCoop'});return true}
  computeUtilities(){const dry=this.s.plots.some(p=>p.crop&&!p.watered&&!p.ready);const u={idle:.18,follow:this.dist(this.s.eva,this.s.player)>3?.38:.12,water:this.s.eva.knowsWater&&dry?clamp(.35+.28*this.s.eva.confidence+.20*(1-this.s.eva.sleepiness)):0,feed:this.s.chicken.owned&&this.s.chicken.hunger>=.6?clamp(.42+.45*this.s.chicken.hunger):0,sleep:this.s.eva.sleepiness>=.72?clamp(.35+.6*this.s.eva.sleepiness):0,eat:this.s.eva.hunger>=.75?clamp(.30+.6*this.s.eva.hunger):0};this.s.eva.lastUtility=u;return u;}
  chooseGoal(){const u=this.computeUtilities();const pairs=Object.entries(u).sort((a,b)=>b[1]-a[1]);return pairs[0][0];}
  buildPlan(goal){const dry=this.nearestPlot(p=>p.crop&&!p.watered&&!p.ready);if(goal==='water'&&dry){const plan=[];if(this.s.inventory.wateringCanWater<=0)plan.push({type:'move',target:MAP.water},{type:'refill'});plan.push({type:'move',target:{x:dry.x,y:dry.y},stop:1},{type:'water',plot:dry.id});return plan}
    if(goal==='feed'){const plan=[];if(this.s.inventory.feed<=0)return [{type:'fail',reason:'MISSING_FEED'}];plan.push({type:'move',target:MAP.coop,stop:1},{type:'feed'});return plan}
    if(goal==='sleep')return [{type:'move',target:MAP.bed,stop:0},{type:'sleep'}];
    if(goal==='eat')return [{type:'eat'}];
    if(goal==='follow')return [{type:'move',target:{x:this.s.player.x,y:this.s.player.y},stop:3}];
    return [{type:'idle'}];}
  evaStep(){if(!this.s.eva.currentPlan.length){const goal=this.chooseGoal();this.s.eva.currentGoal=goal;this.s.eva.currentPlan=this.buildPlan(goal);this.event('EVAGoalSelected',{goal,utilities:this.s.eva.lastUtility});this.event('EVAPlanBuilt',{goal,steps:this.s.eva.currentPlan.map(x=>x.type)});}
    const step=this.s.eva.currentPlan[0];if(!step)return 'idle';this.s.eva.currentAction=step.type;let done=false,result=step.type;
    if(step.type==='move'){if(this.dist(this.s.eva,step.target)>(step.stop??0)){this._stepToward(this.s.eva,step.target);result='move'}else done=true}
    else if(step.type==='refill'){this.s.inventory.wateringCanWater=20;this.event('EVAFillWateringCan',{source:'farm_well'});done=true}
    else if(step.type==='water'){const p=this.s.plots.find(x=>x.id===step.plot);done=this._waterPlot(p,'eva');if(!done){this.event('EVAActionFailed',{action:'water',reason:'TARGET_INVALID_OR_DONE'});done=true}}
    else if(step.type==='feed'){this.s.inventory.feed--;this.s.chicken.hunger=.15;this.s.chicken.fedCount++;this.s.eva.actions.push('feed_chicken');this.event('AnimalFed',{actor:'eva',animal:'chicken'});done=true}
    else if(step.type==='sleep'){this.s.eva.sleepiness=.05;this.s.eva.energy=100;this.s.eva.hunger=clamp(this.s.eva.hunger+.08);this.event('EVASlept',{actor:'eva'});done=true}
    else if(step.type==='eat'){this.s.eva.hunger=.15;this.event('EVAAte',{actor:'eva'});done=true}
    else if(step.type==='fail'){this.event('EVAActionFailed',{action:'plan',reason:step.reason});done=true}
    else {this.tick(1);done=true}
    if(done)this.s.eva.currentPlan.shift();if(!this.s.eva.currentPlan.length)this.s.eva.currentAction=null;return result;}
  _stepToward(a,t){if(a.x<t.x)a.x++;else if(a.x>t.x)a.x--;else if(a.y<t.y)a.y++;else if(a.y>t.y)a.y--;this.tick(1);this.event('EVAMoved',{x:a.x,y:a.y})}
  advanceDay(internal=false){if(!internal){this.writeDiary(this.s.day);this.s.day++;this.s.minute=6*60;}this.s.weather=this.s.day%3===0?'Rain':'Clear';this._updatePhase();for(const p of this.s.plots){if(p.crop){if(p.watered||this.s.weather==='Rain')p.growth=Math.min(1,p.growth+.5);p.stage=p.growth>=1?3:p.growth>=.5?2:1;p.ready=p.growth>=1;p.watered=this.s.weather==='Rain';}}if(this.s.chicken.owned){this.s.chicken.hunger=Math.min(1,this.s.chicken.hunger+.38);if(this.s.chicken.hunger<.6)this.s.chicken.eggs++;}this.s.eva.sleepiness=clamp(this.s.eva.sleepiness+.18);this.event('GameDayAdvanced',{day:this.s.day,weather:this.s.weather});}
  sleepPlayer(){if(this.dist(this.s.player,MAP.home)>2)return false;this.writeDiary(this.s.day);this.event('PlayerSlept',{day:this.s.day});this.s.day++;this.s.minute=6*60;this.s.player.energy=100;this.advanceDay(true);return true}
  writeDiary(day){if(this.s.eva.diary.some(d=>d.day===day))return;const es=this.s.events.filter(e=>e.day===day);const parts=[];if(es.some(e=>e.type==='KnowledgeLearned'))parts.push('今天我終於看懂了澆水的方法。');if(es.some(e=>e.type==='CropHarvested'))parts.push('我們收成了白蘿蔔。');if(es.some(e=>e.type==='ChickenJoinedFarm'))parts.push('農場多了一隻雞。');if(es.some(e=>e.type==='AnimalFed'))parts.push('我第一次自己照顧了雞。');if(!parts.length)parts.push('今天很平靜，我還在熟悉這個地方。');const ids=es.filter(e=>['KnowledgeLearned','CropHarvested','ChickenJoinedFarm','AnimalFed'].includes(e.type)).map(e=>e.id);const d={day,text:parts.join(''),eventIds:ids};this.s.eva.diary.push(d);this.event('DailyReflectionCreated',{day,eventIds:ids});}
  save(storage,key='genesis-farm-eva-vs'){this.s.save.lastSavedDay=this.s.day;this.s.save.lastSavedMinute=this.s.minute;storage.setItem(key,JSON.stringify(this.s));this.event('SaveCompleted',{slot:this.s.save.slot,eventCount:this.s.events.length});}
  load(storage,key='genesis-farm-eva-vs'){const raw=storage.getItem(key);if(!raw)return false;this.s=JSON.parse(raw);this._seq=this.s.events.length;this.event('ReloadCompleted',{slot:this.s.save.slot});return true}
  offline(minutes=120,txn=`OFFLINE-${this.s.day}-${minutes}`){if(this.s.offline.lastTxn===txn){this.event('OfflineSimulationSkippedDuplicate',{txn});return false}this.s.offline.lastTxn=txn;this.s.offline.totalMinutes+=minutes;if(this.s.chicken.owned)this.s.chicken.hunger=Math.min(1,this.s.chicken.hunger+minutes/120*.10);for(const p of this.s.plots){if(p.crop&&p.watered)p.growth=Math.min(1,p.growth+minutes/(24*60)*.5);p.stage=p.growth>=1?3:p.growth>=.5?2:1;p.ready=p.growth>=1;}this.event('OfflineSimulationCompleted',{minutes,txn});return true}
}
