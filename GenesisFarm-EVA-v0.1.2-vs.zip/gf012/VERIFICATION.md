# Verification — 0.1.2-vs

Automated core verification is performed with `node Prototype/verify.mjs`.

Required PASS conditions:
- EVA learns watering only after two valid observations.
- Utility selector chooses watering when appropriate.
- GOAP-style plan contains a water step and executes it.
- Crop stage advances to ready state.
- First harvest creates a Core Memory.
- Chicken purchase is atomic and EVA chooses the feed goal when hunger is high.
- Player sleep creates an evidence-linked diary entry.
- Save slot marker persists through reload.
- Offline simulation is idempotent for the same transaction ID.

Unity Editor / Windows Player / Android APK remain UNVERIFIED in this environment.
