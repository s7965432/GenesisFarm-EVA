# Changelog

## 0.1.2-vs
- Added explicit EVA Utility scoring and visible score breakdown.
- Added GOAP-like plan generation and stepwise action execution.
- Added crop growth stages (seedling, grown, ready) and stage-based visuals.
- Added time-of-day phases and player sleep flow.
- Added EVA sleep/eat needs as utility candidates.
- Added save slot state display and saved day marker.
- Added evidence-linked diary generation retained through save/load.
- Expanded verification for Utility goal selection, plan building, crop stage progression, chicken care, sleep, save/reload, and offline idempotence.

## 0.1.1-vs
- First interactive farm scene prototype.
