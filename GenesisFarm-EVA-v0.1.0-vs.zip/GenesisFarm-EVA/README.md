# GenesisFarm-EVA / 新生農場：EVA

Version: 0.1.0-vs

Vertical Slice verification target:
- boot world
- plant/water/harvest radish
- EVA observes watering and learns
- EVA autonomously waters
- first harvest becomes core memory
- chicken hunger + EVA autonomous feeding
- save/reload
- offline simulation transaction is idempotent
